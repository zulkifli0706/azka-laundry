<?php
/**
 * Ambil teks "Nama (qty satuan) = Rp x" untuk SEMUA item transaksi dari
 * database — SATU string per item, TANPA nomor urut di depan (nomornya
 * ditambahkan belakangan oleh ringkasBarisLayanan(), supaya kalau item
 * lebih dari MAX_SLOT_ITEM_WA, sisa item bisa digabung di bawah 1 nomor
 * tanpa perlu nomor baru per item).
 */
function ambilItemLayanan(PDO $pdo, int $transaksiId): array {
    $stmt = $pdo->prepare("
        SELECT dt.qty, dt.subtotal, COALESCE(ib.nama_item, dt.keterangan, 'Item') AS nama_item, COALESCE(ib.satuan, '') AS satuan
        FROM detail_transaksi dt
        LEFT JOIN detail_barang ib ON ib.id_barang = dt.detail_barang_id
        WHERE dt.transaksi_id = ?
    ");
    $stmt->execute([$transaksiId]);
    $items = $stmt->fetchAll();

    $hasil = [];
    foreach ($items as $it) {
        $qtyFmt = rtrim(rtrim((string)$it['qty'], '0'), '.');
        $satuan = $it['satuan'] !== '' ? ' ' . $it['satuan'] : '';
        $hasil[] = "{$it['nama_item']} ({$qtyFmt}{$satuan}) = Rp " . number_format($it['subtotal'], 0, ',', '.');
    }
    return $hasil;
}

/**
 * Jumlah maksimum SLOT baris item yang tersedia di template
 * `pesanan_diterima_v3` (lihat docs/whatsapp-templates.md). Untuk tiap
 * jumlah barang 1..5 ada template terpisah (_v3, _2, _3, _4, _5). Ini
 * BUKAN pembatasan Meta, tapi keputusan desain supaya tidak perlu submit
 * template baru tiap kali ada nota dengan jumlah barang beda-beda tanpa
 * batas. `pesanan_selesai_v4` pakai batas yang BEDA (lihat
 * MAX_SLOT_ITEM_WA_SELESAI di bawah) -- makanya ringkasBarisLayanan() &
 * namaTemplateItem() menerima $maxSlot sebagai parameter, bukan hardcode
 * ke konstanta ini.
 */
const MAX_SLOT_ITEM_WA = 5;

/**
 * Batas slot khusus untuk `pesanan_selesai_v4` (struk + lampiran invoice
 * PDF) -- dinaikkan ke 8 supaya nota dengan sampai 8 jenis layanan tetap
 * tampil sebagai baris terpisah-pisah di pesan WA (tidak digabung sejak
 * item ke-5 seperti template lama). Perlu template
 * `pesanan_selesai_v4_6`, `_7`, `_8` dibuat di WhatsApp Manager -- lihat
 * docs/whatsapp-templates.md bagian 3f.
 */
const MAX_SLOT_ITEM_WA_SELESAI = 8;

/**
 * Susun & nomori baris "Rincian layanan" dari hasil ambilItemLayanan(),
 * disesuaikan dengan jumlah slot {{n}} yang tersedia di template WA:
 * - Kalau item <= $maxSlot: tiap item dapat nomor & baris sendiri
 *   ("1. ...", "2. ...", dst), 1 slot {{n}} per item.
 * - Kalau item > $maxSlot: ($maxSlot-1) item pertama tetap bernomor &
 *   berbaris sendiri-sendiri. SISA item (ke-$maxSlot dst) TETAP dinomori
 *   berurutan (nomornya jalan terus, bukan diulang), tapi semuanya
 *   digabung jadi SATU baris terakhir (dipisah koma) karena cuma 1 slot
 *   {{n}} yang tersisa dan Meta melarang newline di dalam 1 parameter.
 *   Contoh ($maxSlot=8, ada 10 item):
 *   "8. Selimut (1 pcs) = Rp 15.000, 9. Boneka (1 pcs) = Rp 8.000,
 *   10. Setrika Saja (2 kg) = Rp 10.000".
 *
 * PENTING: ini cuma menyusun tampilan RINCIAN LAYANAN di pesan WA. Total
 * biaya yang dikirim tetap dihitung dari trx.total_harga (SEMUA item),
 * bukan cuma dari baris yang ditampilkan di sini — lihat pemanggilnya.
 *
 * @param int $maxSlot Batas jumlah baris terpisah (5 untuk pesanan_diterima
 *                      via MAX_SLOT_ITEM_WA, 8 untuk pesanan_selesai via
 *                      MAX_SLOT_ITEM_WA_SELESAI).
 */
function ringkasBarisLayanan(array $items, int $maxSlot = MAX_SLOT_ITEM_WA): array {
    if (empty($items)) {
        return ['-'];
    }
    if (count($items) <= $maxSlot) {
        $baris = [];
        foreach ($items as $i => $teks) {
            $baris[] = ($i + 1) . ". {$teks}";
        }
        return $baris;
    }

    $baris = [];
    for ($i = 0; $i < $maxSlot - 1; $i++) {
        $baris[] = ($i + 1) . ". {$items[$i]}";
    }
    $sisaItem = array_slice($items, $maxSlot - 1);
    $sisaBernomor = [];
    foreach ($sisaItem as $j => $teks) {
        $sisaBernomor[] = ($maxSlot + $j) . ". {$teks}";
    }
    $baris[] = implode(', ', $sisaBernomor);
    return $baris;
}

/**
 * Tentukan nama template Meta yang harus dipakai berdasarkan jumlah baris
 * item yang AKAN ditampilkan (hasil ringkasBarisLayanan(), jadi sudah
 * dijamin antara 1..$maxSlot).
 *
 * Konvensi penamaan: template 1 item = nama dasar tanpa akhiran (template
 * yang sudah approved), template 2..N item = nama dasar + "_2".."_N".
 * Lihat docs/whatsapp-templates.md untuk body lengkap tiap varian yang
 * perlu dibuat di WhatsApp Manager.
 *
 * @param int $maxSlot Harus SAMA dengan yang dipakai di ringkasBarisLayanan()
 *                      supaya nama template & jumlah variabel body sinkron.
 */
function namaTemplateItem(string $namaDasar, int $jumlahBarisDitampilkan, int $maxSlot = MAX_SLOT_ITEM_WA): string {
    $n = max(1, min($jumlahBarisDitampilkan, $maxSlot));
    return $n === 1 ? $namaDasar : $namaDasar . '_' . $n;
}


/**
 * Kirim notifikasi WhatsApp "pesanan diterima" untuk satu transaksi,
 * dibangun ulang dari database (bukan dari variabel form) supaya bisa
 * dipanggil belakangan lewat antrian (kirim_notif_wa.php), bukan langsung
 * saat simpan_transaksi.php diproses.
 *
 * Memakai template Meta WhatsApp `pesanan_diterima_v3` (1 barang) atau
 * varian `_2`/`_3`/`_4`/`_5` (2-5+ barang), dipilih otomatis sesuai jumlah
 * barang di transaksi — lihat docs/whatsapp-templates.md untuk urutan
 * variabel & isi tiap template.
 */
function kirimNotifTransaksiBaru(PDO $pdo, int $transaksiId): bool {
    $stmt = $pdo->prepare("
        SELECT t.nama_pelanggan, t.no_hp_pelanggan, t.id_nota, t.total_harga, t.total_dibayar, t.status_bayar, t.tanggal_estimasi
        FROM transaksi t WHERE t.id_transaksi = ?
    ");
    $stmt->execute([$transaksiId]);
    $trx = $stmt->fetch();
    if (!$trx) return false;

    $tglEst   = !empty($trx['tanggal_estimasi']) ? date('d/m/Y', strtotime($trx['tanggal_estimasi'])) : '-';
    // Total selalu dihitung dari trx.total_harga (SEMUA barang), walaupun
    // baris "Rincian layanan" di bawah bisa diringkas kalau barang > 5.
    $totalFmt = 'Rp ' . number_format($trx['total_harga'], 0, ',', '.');

    $bayar = rincianPembayaranStruk($pdo, $transaksiId, (float)$trx['total_harga'], (float)$trx['total_dibayar']);

    $barisLayanan = ringkasBarisLayanan(ambilItemLayanan($pdo, $transaksiId), MAX_SLOT_ITEM_WA);
    $templateName = namaTemplateItem('pesanan_diterima_v3', count($barisLayanan), MAX_SLOT_ITEM_WA);

    $params = array_merge(
        [$trx['nama_pelanggan'], $trx['id_nota'], $tglEst],
        $barisLayanan,
        [$totalFmt, $bayar['dibayar'], $bayar['metode'], $bayar['sisa']]
    );

    require_once __DIR__ . '/meta_whatsapp.php';
    $waResult = kirimWATemplate($trx['no_hp_pelanggan'], $templateName, $params);
    if (!$waResult['success']) {
        error_log('Gagal kirim WA notif transaksi baru untuk nota ' . $trx['id_nota'] . ' (template ' . $templateName . '): ' . json_encode($waResult['response']));
    }
    return $waResult['success'];
}

/**
 * Kirim notifikasi WhatsApp "pesanan selesai" (struk) untuk satu
 * transaksi yang baru saja dikonfirmasi diambil pelanggan
 * (status_cucian.status = 'selesai', dipicu dari siap_diambil.php).
 *
 * Dipanggil lewat kirim_notif_wa.php (type='selesai'), diantre bareng
 * notifikasi WA lain lewat includes/notif_wa_widget.php (jeda 20-30 detik).
 *
 * Memakai template Meta WhatsApp `pesanan_selesai_v4` (1 barang) atau
 * varian `_2`/`_3`/`_4`/`_5` (2-5+ barang), dipilih otomatis sesuai jumlah
 * barang di transaksi — lihat docs/whatsapp-templates.md.
 *
 * Sejak v4, template ini punya HEADER bertipe Document: pesan WA yang
 * diterima pelanggan otomatis melampirkan file invoice PDF yang bisa
 * mereka download (dibuat on-demand lewat invoice.php, lihat
 * includes/invoice_pdf.php). Body-nya sendiri (teks) TIDAK berubah dari
 * v3 -- cuma nama template & tambahan header dokumen.
 */
function kirimNotifSelesai(PDO $pdo, int $transaksiId): bool {
    $stmt = $pdo->prepare("
        SELECT t.nama_pelanggan, t.no_hp_pelanggan, t.id_nota, t.total_harga, t.total_dibayar, t.status_bayar
        FROM transaksi t WHERE t.id_transaksi = ?
    ");
    $stmt->execute([$transaksiId]);
    $trx = $stmt->fetch();
    if (!$trx) return false;

    // Total selalu dihitung dari trx.total_harga (SEMUA barang), walaupun
    // baris "Rincian layanan" di bawah bisa diringkas kalau barang > 5.
    $totalFmt = 'Rp ' . number_format($trx['total_harga'], 0, ',', '.');

    $bayar = rincianPembayaranStruk($pdo, $transaksiId, (float)$trx['total_harga'], (float)$trx['total_dibayar']);

    $barisLayanan = ringkasBarisLayanan(ambilItemLayanan($pdo, $transaksiId), MAX_SLOT_ITEM_WA_SELESAI);
    $templateName = namaTemplateItem('pesanan_selesai_v4', count($barisLayanan), MAX_SLOT_ITEM_WA_SELESAI);

    $params = array_merge(
        [$trx['nama_pelanggan'], $trx['id_nota']],
        $barisLayanan,
        [$totalFmt, $bayar['dibayar'], $bayar['metode'], $bayar['sisa']]
    );

    require_once __DIR__ . '/meta_whatsapp.php';
    require_once __DIR__ . '/invoice_pdf.php';

    $token       = tokenInvoice($trx['id_nota']);
    $invoiceUrl  = APP_URL . '/invoice.php?nota=' . urlencode($trx['id_nota']) . '&t=' . $token;
    $namaFilePdf = 'Invoice-' . preg_replace('/[^A-Za-z0-9\-_]/', '', $trx['id_nota']) . '.pdf';

    $waResult = kirimWATemplateDokumen($trx['no_hp_pelanggan'], $templateName, $invoiceUrl, $namaFilePdf, $params);
    if (!$waResult['success']) {
        error_log('Gagal kirim WA struk selesai untuk nota ' . $trx['id_nota'] . ' (template ' . $templateName . '): ' . json_encode($waResult['response']));
    }
    return $waResult['success'];
}
