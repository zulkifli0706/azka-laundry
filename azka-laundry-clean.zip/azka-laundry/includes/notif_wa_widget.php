<?php
/**
 * Widget antrian notifikasi WA terpadu — dipakai bareng oleh:
 *  - notifikasi "transaksi baru diterima" (dashboard_kasir.php)
 *  - notifikasi "siap diambil" (proses.php)
 *  - notifikasi "estimasi diperpanjang / telat" (dashboard_pencucian.php, antrian.php, sedang_diproses.php)
 *  - notifikasi "pesanan selesai" berupa struk (siap_diambil.php)
 *
 * Include di halaman (di mana saja, posisinya fixed di layar) SETELAH
 * $csrfTokenJs di-set. Boleh juga set $antrianNotifWaAwal (array of
 * ['type' => 'baru'|'siap'|'terlambat'|'selesai', 'transaksi_id' => int]) untuk
 * langsung diantre begitu halaman dimuat.
 *
 * Tombol aksi di halaman (mis. "Lanjut Tahap") TETAP bisa dipencet
 * berkali-kali tanpa dikunci/disabled -- setiap klik cuma nambah item baru
 * ke antrean (dicegah dobel lewat transaksi_id yang sama), lalu antrean
 * inilah yang mengatur jeda pengiriman sebenarnya ke Meta WhatsApp Cloud API
 * (~1 detik acak per pesan, sekadar jaga-jaga burst rate limit — bukan lagi
 * 20-30 detik seperti versi SMS/Fonnte lama). Banner di bawah menampilkan status "berhasil diproses,
 * akan terkirim dalam X detik" secara real-time.
 */
$antrianJson = json_encode($antrianNotifWaAwal ?? []);
?>
<div id="notifWaBar" style="display:none;position:fixed;top:16px;right:16px;z-index:9999;
     max-width:360px;background:#184B85;color:#fff;padding:12px 16px;border-radius:12px;
     box-shadow:0 8px 24px rgba(0,0,0,.25);font-size:13px;font-weight:600;line-height:1.4;
     display:flex;align-items:flex-start;gap:10px;">
  <i class="fa-solid fa-paper-plane" style="margin-top:2px"></i>
  <span id="notifWaBarText">Menyiapkan notifikasi WA...</span>
</div>
<script>
(function () {
    const CSRF_TOKEN = <?= json_encode($csrfTokenJs) ?>;
    const QUEUE_KEY   = 'azkaNotifWaQueue';
    const NEXT_KEY    = 'azkaNotifWaNextAllowed';
    const LABEL = { baru: 'transaksi baru', siap: 'siap diambil', terlambat: 'estimasi diperpanjang', selesai: 'pesanan selesai (struk)' };

    function getQueue() { try { return JSON.parse(sessionStorage.getItem(QUEUE_KEY) || '[]'); } catch (e) { return []; } }
    function setQueue(q) { sessionStorage.setItem(QUEUE_KEY, JSON.stringify(q)); }
    function jedaAcak() { return 800 + Math.random() * 400; } // ~0.8-1.2 detik (jaga-jaga burst rate limit Meta, bukan lagi 20-30dtk ala SMS)

    const bar = document.getElementById('notifWaBar');
    const barText = document.getElementById('notifWaBarText');
    let countdownTimer = null;

    function updateBar() {
        const q = getQueue();
        if (!q.length) {
            bar.style.display = 'none';
            if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
            return;
        }
        bar.style.display = 'flex';
        const nextAllowed = parseInt(sessionStorage.getItem(NEXT_KEY) || '0', 10);
        const sisaDetik = Math.max(0, Math.ceil((nextAllowed - Date.now()) / 1000));
        const jenis = LABEL[q[0].type] || 'WA';
        const sisaPesan = q.length > 1 ? ` (${q.length} pesan dalam antrean)` : '';
        barText.textContent = sisaDetik <= 0
            ? `Mengirim notifikasi ${jenis}...${sisaPesan}`
            : `✓ Berhasil diproses — notifikasi ${jenis} akan terkirim dalam ${sisaDetik} detik.${sisaPesan}`;
    }

    function jadwalkanBerikutnya() {
        const q = getQueue();
        if (!q.length) { updateBar(); return; }
        if (!countdownTimer) countdownTimer = setInterval(updateBar, 1000);
        updateBar();
        const nextAllowed = parseInt(sessionStorage.getItem(NEXT_KEY) || '0', 10);
        setTimeout(kirimBerikutnya, Math.max(0, nextAllowed - Date.now()));
    }

    function kirimBerikutnya() {
        const q = getQueue();
        if (!q.length) { updateBar(); return; }
        const item = q.shift();
        setQueue(q);
        updateBar();

        const fd = new FormData();
        fd.append('type', item.type);
        fd.append('transaksi_id', item.transaksi_id);
        fd.append('csrf_token', CSRF_TOKEN);

        fetch('kirim_notif_wa.php', { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(res => res.json())
            .then(data => console.log(`Notif WA (${item.type}) transaksi #${item.transaksi_id}:`, data.wa_sent ? 'terkirim' : 'GAGAL', data))
            .catch(err => console.error('Gagal kirim notif WA:', err))
            .finally(() => {
                sessionStorage.setItem(NEXT_KEY, String(Date.now() + jedaAcak()));
                jadwalkanBerikutnya();
            });
    }

    // Dipanggil dari halaman manapun yang include widget ini, kapan saja
    // (termasuk berkali-kali beruntun / "di-spam") -- aman, karena cuma
    // menambah ke antrean, tidak langsung mengirim.
    window.antrekanNotifWa = function (type, transaksiId) {
        const q = getQueue();
        if (!q.some(it => it.type === type && it.transaksi_id === transaksiId)) {
            q.push({ type: type, transaksi_id: transaksiId });
            setQueue(q);
        }
        jadwalkanBerikutnya();
    };

    // Antrean awal dari server (mis. batch nota yang baru diperpanjang estimasinya).
    (<?= $antrianJson ?>).forEach(function (it) {
        window.antrekanNotifWa(it.type, it.transaksi_id);
    });

    // Lanjutkan sisa antrean dari sebelum halaman ini di-reload.
    jadwalkanBerikutnya();
})();
</script>
