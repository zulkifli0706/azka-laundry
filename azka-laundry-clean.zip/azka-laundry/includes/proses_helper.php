<?php
/**
 * Helper untuk alur tahapan proses laundry yang berbeda-beda
 * tergantung tipe_proses item (cuci_kering, cuci_setrika,
 * setrika_saja, item_khusus).
 *
 * Urutan tahap baku: cuci -> keringkan -> setrika -> kemas.
 * Setiap tipe_proses cuma memakai sebagian tahap ini (selain
 * 'kemas' yang selalu berlaku untuk semua transaksi).
 */

// Urutan kanonik semua tahap yang mungkin ada.
const URUTAN_TAHAP = ['cuci', 'keringkan', 'setrika', 'kemas'];

// Tahap apa saja yang dipakai untuk masing-masing tipe_proses
// (di luar 'kemas' yang otomatis ditambahkan di akhir untuk semua tipe).
function tahapUntukTipeProses(string $tipeProses): array {
    return match ($tipeProses) {
        'cuci_kering'  => ['cuci', 'keringkan'],
        'cuci_setrika' => ['cuci', 'keringkan', 'setrika'],
        'setrika_saja' => ['setrika'],
        'item_khusus'  => ['cuci', 'keringkan', 'setrika'],
        default        => ['cuci', 'keringkan', 'setrika'],
    };
}

// Tahap yang boleh dipakai dalam urutan proses KUSTOM. Beda dari template
// biasa, di sini 'kemas' JUGA boleh dipilih & diposisikan bebas oleh owner
// (bukan otomatis selalu di akhir) — makanya ada 4 slot Tahap 1-4 di form.
const TAHAP_KUSTOM_VALID = ['cuci', 'keringkan', 'setrika', 'kemas'];

/**
 * Ubah string custom_tahap (mis. "cuci,setrika") dari database jadi
 * array tahap yang valid & terurut, buang kode yang tidak dikenal /
 * duplikat. String kosong atau null menghasilkan array kosong, artinya
 * "tidak ada override" -> caller harus fallback ke template tipe_proses.
 *
 * @return string[] contoh: ['cuci', 'setrika']
 */
function parseCustomTahap(?string $customTahap): array {
    if ($customTahap === null || trim($customTahap) === '') {
        return [];
    }
    $tahap = array_map('trim', explode(',', $customTahap));
    $tahap = array_values(array_unique(array_filter(
        $tahap,
        fn($t) => in_array($t, TAHAP_KUSTOM_VALID, true)
    )));
    return $tahap;
}

/**
 * Sumber kebenaran tunggal untuk "tahap apa saja yang dipakai satu
 * barang" (di luar 'kemas'). Kalau owner sudah mengatur urutan proses
 * kustom untuk barang ini (kolom detail_barang.custom_tahap terisi),
 * urutan kustom itu yang dipakai. Kalau tidak, fallback ke template
 * default berdasarkan tipe_proses (perilaku lama).
 *
 * @return string[] contoh: ['cuci', 'setrika']
 */
function tahapUntukItem(string $tipeProses, ?string $customTahap = null): array {
    $kustom = parseCustomTahap($customTahap);
    return !empty($kustom) ? $kustom : tahapUntukTipeProses($tipeProses);
}

/**
 * Ambil daftar tipe_proses dari semua item dalam satu transaksi.
 * Kalau transaksi tidak punya item dengan tipe_proses (misal item
 * lama tanpa detail_barang_id / sudah dihapus dari katalog), fallback
 * ke 'cuci_setrika' supaya alur tetap lengkap (lebih aman daripada
 * melewatkan tahap yang mungkin sebenarnya perlu).
 *
 * @return string[] daftar tipe_proses unik yang dipakai transaksi ini
 */
function tipeProsesTransaksi(PDO $pdo, int $transaksiId): array {
    $stmt = $pdo->prepare("
        SELECT DISTINCT COALESCE(il.tipe_proses, 'cuci_setrika') AS tipe_proses, il.custom_tahap,
               kl.nama_kategori
        FROM detail_transaksi dt
        LEFT JOIN detail_barang il    ON il.id_barang = dt.detail_barang_id
        LEFT JOIN kategori_barang kl ON kl.id_kategori = il.kategori_id
        WHERE dt.transaksi_id = ?
    ");
    $stmt->execute([$transaksiId]);
    $rows = $stmt->fetchAll();
    // Tiap baris: ['tipe_proses' => string, 'custom_tahap' => ?string, 'nama_kategori' => ?string]
    return !empty($rows) ? $rows : [['tipe_proses' => 'cuci_setrika', 'custom_tahap' => null, 'nama_kategori' => null]];
}

/**
 * Hitung urutan tahap yang berlaku untuk satu transaksi: gabungan
 * (union) tahap yang dibutuhkan semua item di dalamnya, diurutkan
 * sesuai URUTAN_TAHAP, dan selalu diakhiri 'kemas'.
 *
 * Contoh: nota berisi item Cuci Kering + Setrika Saja
 *   -> gabungan: cuci, keringkan, setrika, kemas (union keduanya)
 *
 * @return string[] contoh: ['cuci', 'keringkan', 'setrika', 'kemas']
 */
function tahapUntukTransaksi(PDO $pdo, int $transaksiId): array {
    $daftarItem = tipeProsesTransaksi($pdo, $transaksiId);
    $terpakai   = ['kemas' => true]; // kemas selalu ada
    foreach ($daftarItem as $it) {
        foreach (tahapUntukItem($it['tipe_proses'], $it['custom_tahap'] ?? null) as $t) {
            $terpakai[$t] = true;
        }
    }
    // Urutkan sesuai URUTAN_TAHAP baku
    return array_values(array_filter(URUTAN_TAHAP, fn($t) => !empty($terpakai[$t])));
}

/**
 * Tipe proses "dominan" satu transaksi, dipakai cuma untuk memilih
 * LABEL tahap yang paling pas (mis. 'Finishing' vs 'Disetrika').
 * Kalau item campur-campur, ambil yang pertama ditemukan saja —
 * tidak memengaruhi tahap mana yang aktif, cuma memengaruhi teks
 * yang ditampilkan.
 */
function tipeDominanTransaksi(PDO $pdo, int $transaksiId): string {
    $daftarItem = tipeProsesTransaksi($pdo, $transaksiId);
    return $daftarItem[0]['tipe_proses'] ?? 'cuci_setrika';
}

/**
 * Nama kategori "dominan" satu transaksi — pasangan tipeDominanTransaksi(),
 * dipakai labelTahap() buat nentuin istilah "cuci" yang pas (mis. "Dicuci"
 * vs "Dibersihkan" untuk Tas & Koper). Sama seperti tipeDominanTransaksi,
 * kalau item campur-campur cuma ambil kategori item pertama yang ditemukan.
 */
function kategoriDominanTransaksi(PDO $pdo, int $transaksiId): ?string {
    $daftarItem = tipeProsesTransaksi($pdo, $transaksiId);
    return $daftarItem[0]['nama_kategori'] ?? null;
}

/**
 * Nama kategori (kategori_barang.nama_kategori) yang prosesnya TIDAK
 * direndam air, jadi tahap 'cuci' disebut "Dibersihkan" (bukan "Dicuci")
 * — sesuai hasil wawancara owner di lampiran daftar barang & harga.
 * Kategori item_khusus LAIN (Sepatu, Jas) tetap disebut "Dicuci" seperti
 * biasa karena tetap melalui proses cuci (lihat lampiran: kolom Tahapan
 * Proses mereka mulai dari kata "Cuci", bukan "Bersihkan Permukaan").
 */
const KATEGORI_TANPA_RENDAM = ['Tas & Koper'];

/**
 * Label tampilan untuk satu kode tahap. $namaKategori (opsional) dipakai
 * buat kasus kategori yang istilah "cuci"-nya beda (lihat
 * KATEGORI_TANPA_RENDAM) — kalau tidak diisi/tidak cocok, jatuh ke label
 * baku biasa. $tipeDominan sengaja dipertahankan di parameter (dipakai
 * banyak pemanggil lama) walau sekarang tidak lagi memengaruhi hasil,
 * supaya tidak perlu ubah urutan argumen di semua pemanggil sekaligus.
 */
function labelTahap(string $tahap, string $tipeDominan = 'cuci_setrika', ?string $namaKategori = null): string {
    if ($tahap === 'cuci' && $namaKategori !== null && in_array($namaKategori, KATEGORI_TANPA_RENDAM, true)) {
        return 'Dibersihkan';
    }

    return match ($tahap) {
        'cuci'      => 'Dicuci',
        'keringkan' => 'Dikeringkan',
        'setrika'   => 'Disetrika',
        'kemas'     => 'Dikemas',
        default     => ucfirst($tahap),
    };
}

/**
 * Ikon Font Awesome untuk tiap tahap (dipakai di badge UI).
 */
function ikonTahap(string $tahap): string {
    return match ($tahap) {
        'cuci'      => 'fa-water',
        'keringkan' => 'fa-wind',
        'setrika'   => 'fa-fire-flame-simple',
        'kemas'     => 'fa-box',
        default     => 'fa-rotate',
    };
}

/**
 * Status proses untuk SATU ITEM di dalam transaksi yang sedang berjalan.
 * Dipakai untuk tombol "Detail" di halaman cek status, supaya pelanggan
 * bisa lihat kalau item A (mis. setrika_saja) masih "Sedang Disetrika"
 * sementara item B (mis. cuci_kering, yang tidak butuh tahap setrika)
 * sudah lebih dulu selesai dan tinggal menunggu dikemas bareng.
 *
 * @return array{label:string, state:string, icon:string}
 *   state: 'active' (sedang dikerjakan), 'done' (tahap item ini sudah
 *   kelar, tinggal nunggu dikemas bareng batch), atau 'waiting' (belum
 *   giliran / masih dalam antrian).
 */
function statusItemProses(string $tipeProses, string $statusTransaksi, ?string $tahapAktif, ?string $namaKategori = null): array {
    if ($statusTransaksi === 'dalam_antrian') {
        return ['label' => 'Menunggu Antrian', 'state' => 'waiting', 'icon' => ''];
    }
    if ($statusTransaksi === 'siap_diambil' || $statusTransaksi === 'selesai') {
        return ['label' => 'Selesai Diproses', 'state' => 'done', 'icon' => ''];
    }
    if ($statusTransaksi !== 'sedang_diproses' || $tahapAktif === null) {
        return ['label' => 'Menunggu Antrian', 'state' => 'waiting', 'icon' => ''];
    }

    // Semua item ikut dikemas bareng begitu tahap batch sudah 'kemas'.
    if ($tahapAktif === 'kemas') {
        return ['label' => 'Sedang ' . labelTahap('kemas', $tipeProses, $namaKategori), 'state' => 'active', 'icon' => ''];
    }

    $tahapItem = tahapUntukTipeProses($tipeProses);

    // Tahap batch yang aktif sekarang memang salah satu tahap yang
    // dibutuhkan item ini -> item ini sedang dikerjakan.
    if (in_array($tahapAktif, $tahapItem, true)) {
        $ikon = match ($tahapAktif) {
            'cuci'      => '',
            'keringkan' => '',
            'setrika'   => '',
            default     => '',
        };
        return ['label' => 'Sedang ' . labelTahap($tahapAktif, $tipeProses, $namaKategori), 'state' => 'active', 'icon' => $ikon];
    }

    // Tahap aktif bukan bagian dari tahap yang dibutuhkan item ini.
    // Cek apakah semua tahap item ini sudah lewat (berarti item ini
    // sudah beres duluan) atau belum sampai gilirannya.
    $idxAktif     = array_search($tahapAktif, URUTAN_TAHAP, true);
    $idxTahapItem = array_map(fn($t) => array_search($t, URUTAN_TAHAP, true), $tahapItem);
    $idxMaxItem   = !empty($idxTahapItem) ? max($idxTahapItem) : -1;

    if ($idxMaxItem < $idxAktif) {
        return ['label' => 'Sudah Selesai — Menunggu Dikemas', 'state' => 'done', 'icon' => ''];
    }

    return ['label' => 'Menunggu Giliran', 'state' => 'waiting', 'icon' => ''];
}

/**
 * Tentukan tahap SELANJUTNYA untuk transaksi tsb, berdasar tahap
 * yang sedang berjalan sekarang. Return null kalau tahap sekarang
 * sudah yang terakhir (artinya transaksi siap pindah ke status
 * 'siap_diambil', bukan lanjut tahap lagi).
 */
function tahapBerikutnya(PDO $pdo, int $transaksiId, ?string $tahapSekarang): ?string {
    $urutan = tahapUntukTransaksi($pdo, $transaksiId);
    if ($tahapSekarang === null) {
        return $urutan[0] ?? null;
    }
    $idx = array_search($tahapSekarang, $urutan, true);
    if ($idx === false) {
        // Tahap sekarang tidak ada dalam daftar (data tidak konsisten) — mulai dari awal lagi.
        return $urutan[0] ?? null;
    }
    return $urutan[$idx + 1] ?? null; // null = sudah tahap terakhir
}

/* =====================================================================
 * TAHAP PER-ITEM (real, disimpan di tabel detail_status)
 *
 * Berbeda dari fungsi-fungsi di atas yang bekerja di level TRANSAKSI
 * (satu tahap untuk seluruh nota), bagian ini menggerakkan tahap
 * SATU ITEM saja, independen dari item lain dalam nota yang sama.
 * 'kemas' tetap jadi tahap terakhir tiap item — begitu SEMUA item
 * sebuah nota sampai 'kemas', nota otomatis pindah ke 'siap_diambil'.
 * ===================================================================== */

/**
 * Daftar tahap lengkap yang dilalui SATU item.
 * - Kalau barang punya custom_tahap: urutannya PERSIS sesuai pilihan owner
 *   (termasuk posisi 'kemas', boleh di tengah/awal, bukan cuma di akhir).
 *   Kalau owner lupa memasukkan 'kemas', otomatis ditambahkan di akhir
 *   sebagai jaga-jaga supaya nota tetap bisa selesai.
 * - Kalau tidak ada custom_tahap: pakai template baku dari tipe_proses,
 *   selalu diakhiri 'kemas' (perilaku lama, tidak berubah).
 *
 * @return string[] contoh: ['cuci', 'keringkan', 'kemas']
 */
function tahapItemLengkap(string $tipeProses, ?string $customTahap = null): array {
    $kustom = parseCustomTahap($customTahap);
    if (!empty($kustom)) {
        if (!in_array('kemas', $kustom, true)) {
            $kustom[] = 'kemas';
        }
        return $kustom;
    }
    $terpakai = array_fill_keys(tahapUntukTipeProses($tipeProses), true);
    $terpakai['kemas'] = true;
    return array_values(array_filter(URUTAN_TAHAP, fn($t) => !empty($terpakai[$t])));
}

/**
 * Tahap SELANJUTNYA untuk satu item, berdasar tahap item itu sendiri
 * (bukan tahap batch transaksi). Return null kalau item sudah sampai
 * tahap terakhirnya sendiri (item ini sudah beres).
 *
 * $customTahap: urutan proses kustom barang ini (kolom detail_barang.custom_tahap),
 * kalau ada akan dipakai menggantikan template default tipe_proses.
 */
function tahapBerikutnyaItem(string $tipeProses, ?string $tahapSekarang, ?string $customTahap = null): ?string {
    $urutan = tahapItemLengkap($tipeProses, $customTahap);
    if ($tahapSekarang === null) {
        return $urutan[0] ?? null;
    }
    $idx = array_search($tahapSekarang, $urutan, true);
    if ($idx === false) {
        return $urutan[0] ?? null;
    }
    return $urutan[$idx + 1] ?? null;
}

/**
 * Tahap SEBELUMNYA untuk satu item (kebalikan dari tahapBerikutnyaItem()),
 * dipakai tombol "Mundur Tahap" di modal proses.php -- mis. kalau petugas
 * salah pencet "Lanjut" atau barangnya ternyata perlu dikerjakan ulang.
 *
 * Return null kalau item belum mulai (tahap sekarang null) ATAU sudah di
 * tahap paling awal urutannya sendiri -- artinya tidak ada lagi tahap
 * sebelumnya untuk dimundurkan, jadi tombol mundur sebaiknya disembunyikan.
 */
function tahapSebelumnyaItem(string $tipeProses, ?string $tahapSekarang, ?string $customTahap = null): ?string {
    if ($tahapSekarang === null) {
        return null;
    }
    $urutan = tahapItemLengkap($tipeProses, $customTahap);
    $idx    = array_search($tahapSekarang, $urutan, true);
    if ($idx === false || $idx === 0) {
        return null;
    }
    return $urutan[$idx - 1] ?? null;
}

/**
 * Status tampilan SATU ITEM berdasar tahap ASLI-nya di detail_status
 * (bukan tebakan dari tahap batch seperti statusItemProses()).
 *
 * @param string      $tipeProses      tipe_proses item
 * @param string      $statusTransaksi status_cucian.status nota induk
 * @param string|null $tahapItem       detail_status.tahap_proses milik item ini
 */
function statusItemAsli(string $tipeProses, string $statusTransaksi, ?string $tahapItem, ?string $namaKategori = null): array {
    if ($statusTransaksi === 'dalam_antrian') {
        return ['label' => 'Menunggu Antrian', 'state' => 'waiting', 'icon' => ''];
    }
    if ($statusTransaksi === 'siap_diambil' || $statusTransaksi === 'selesai') {
        return ['label' => 'Selesai Diproses', 'state' => 'done', 'icon' => ''];
    }
    if ($statusTransaksi !== 'sedang_diproses') {
        return ['label' => 'Menunggu Antrian', 'state' => 'waiting', 'icon' => ''];
    }
    if ($tahapItem === null) {
        return ['label' => 'Menunggu Giliran', 'state' => 'waiting', 'icon' => ''];
    }
    if ($tahapItem === 'kemas') {
        return ['label' => 'Sudah Dikemas', 'state' => 'done', 'icon' => ''];
    }
    $ikon = match ($tahapItem) {
        'cuci'      => '',
        'keringkan' => '',
        'setrika'   => '',
        default     => '',
    };
    return ['label' => 'Sedang ' . labelTahap($tahapItem, $tipeProses, $namaKategori), 'state' => 'active', 'icon' => $ikon];
}

/**
 * Sinkronkan ringkasan status_cucian setelah tahap satu item berubah:
 *  - Kalau SEMUA item nota ini sudah sampai 'kemas' -> nota otomatis
 *    pindah ke status 'siap_diambil' (return true, caller yang kirim notif WA).
 *  - Kalau belum, status_cucian.tahap_proses diisi ulang dengan tahap
 *    item yang PALING TERTINGGAL (bottleneck), cuma dipakai untuk badge
 *    ringkasan "Tahap batch" di halaman lain yang belum diubah ke per-item.
 *
 * @return bool true kalau nota baru saja pindah ke 'siap_diambil'
 */
function sinkronStatusBatch(PDO $pdo, int $transaksiId, int $userId): bool {
    $stmt = $pdo->prepare("
        SELECT COALESCE(il.tipe_proses, 'cuci_setrika') AS tipe_proses, ds.tahap_proses
        FROM detail_transaksi dt
        LEFT JOIN detail_barang il  ON il.id_barang = dt.detail_barang_id
        LEFT JOIN detail_status ds ON ds.detail_transaksi_id = dt.id_detail_transaksi
        WHERE dt.transaksi_id = ?
    ");
    $stmt->execute([$transaksiId]);
    $items = $stmt->fetchAll();

    if (empty($items)) {
        return false;
    }

    $semuaKemas  = true;
    $idxTertinggal = null;

    foreach ($items as $it) {
        if ($it['tahap_proses'] !== 'kemas') {
            $semuaKemas = false;
        }
        if ($it['tahap_proses'] !== null) {
            $idx = array_search($it['tahap_proses'], URUTAN_TAHAP, true);
            if ($idx !== false && ($idxTertinggal === null || $idx < $idxTertinggal)) {
                $idxTertinggal = $idx;
            }
        }
    }

    if ($semuaKemas) {
        $pdo->prepare("
            UPDATE status_cucian SET status='siap_diambil', tahap_proses=NULL, updated_by=?, updated_at=NOW()
            WHERE transaksi_id=?
        ")->execute([$userId, $transaksiId]);
        return true;
    }

    $tahapBatch = $idxTertinggal !== null ? URUTAN_TAHAP[$idxTertinggal] : null;
    $pdo->prepare("
        UPDATE status_cucian SET tahap_proses=?, updated_by=?, updated_at=NOW()
        WHERE transaksi_id=? AND status='sedang_diproses'
    ")->execute([$tahapBatch, $userId, $transaksiId]);
    return false;
}
/**
 * Kirim notifikasi WhatsApp "siap diambil" untuk satu transaksi.
 * Dipanggil satu-per-satu (dengan jeda dari sisi browser via
 * kirim_notif_wa.php), BUKAN langsung saat status berubah, supaya kalau
 * banyak nota selesai kemas berurutan, pesannya tidak meledak beruntun
 * tanpa jeda.
 *
 * Memakai template Meta WhatsApp `cucian_siap_diambil_v5` — lihat
 * docs/whatsapp-templates.md untuk urutan variabel & isi templatenya.
 * (v4 menambahkan kalimat batas waktu pengambilan maksimal 7 hari,
 * body & jumlah variabelnya sama seperti v3, cuma teksnya beda dikit —
 * makanya perlu nama template baru, bukan menimpa v3 yang sudah approved).
 */
function kirimNotifSiapDiambil(PDO $pdo, int $transaksi_id): bool {
    $stmtTrx = $pdo->prepare("
        SELECT t.nama_pelanggan, t.no_hp_pelanggan, t.id_nota, t.total_harga, t.total_dibayar, t.status_bayar
        FROM transaksi t WHERE t.id_transaksi = ?
    ");
    $stmtTrx->execute([$transaksi_id]);
    $trx = $stmtTrx->fetch();
    if (!$trx) return false;

    $totalFmt = 'Rp ' . number_format($trx['total_harga'], 0, ',', '.');

    $bayar = rincianPembayaranStruk($pdo, $transaksi_id, (float)$trx['total_harga'], (float)$trx['total_dibayar']);

    require_once __DIR__ . '/meta_whatsapp.php';
    $waResult = kirimWATemplate($trx['no_hp_pelanggan'], 'cucian_siap_diambil_v5', [
        $trx['nama_pelanggan'], $trx['id_nota'], $totalFmt,
        $bayar['dibayar'], $bayar['metode'], $bayar['sisa'],
    ]);
    if (!$waResult['success']) {
        error_log('Gagal kirim WA notif siap diambil untuk nota ' . $trx['id_nota'] . ': ' . json_encode($waResult['response']));
    }
    return $waResult['success'];
}
