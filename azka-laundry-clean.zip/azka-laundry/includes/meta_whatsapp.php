<?php
/**
 * Helper untuk mengirim notifikasi WhatsApp menggunakan Meta WhatsApp Cloud API.
 * Dokumentasi resmi: https://developers.facebook.com/docs/whatsapp/cloud-api
 *
 * BEDA PENTING dari Fonnte (includes/fonnte.php):
 * Cloud API TIDAK BISA kirim teks bebas ke pelanggan yang belum chat duluan
 * (business-initiated message). Pesan seperti itu WAJIB pakai "message
 * template" yang sudah dibuat & disetujui Meta di WhatsApp Manager
 * (Meta Business Suite > WhatsApp Manager > Message Templates).
 *
 * Jadi fungsi di sini tidak menerima teks bebas, tapi nama template +
 * daftar isi variabel {{1}}, {{2}}, dst sesuai urutan di body template.
 * Lihat docs/whatsapp-templates.md untuk daftar template & urutan variabel
 * yang dipakai oleh masing-masing fungsi kirimNotif...() di aplikasi ini.
 *
 * Variabel di config.php:
 *   META_WA_TOKEN            Access token permanen (System User) dari App Meta
 *   META_WA_PHONE_NUMBER_ID  Phone Number ID nomor WhatsApp Business terdaftar
 *   META_WA_API_VERSION      Versi Graph API, default v21.0
 *
 * Cara pakai di file lain:
 *   require_once __DIR__ . '/includes/config.php';       // sumber token
 *   require_once __DIR__ . '/includes/meta_whatsapp.php';
 *   kirimWATemplate('081234567890', 'cucian_siap_diambil_v3', ['Budi', 'INV-001', 'Rp 20.000', 'Status Pembayaran: Lunas (dibayar Tunai Rp 20.000)']);
 */

if (!defined('META_WA_TOKEN')) {
    throw new RuntimeException('META_WA_TOKEN belum didefinisikan. Pastikan config.php di-require_once sebelum meta_whatsapp.php.');
}

/**
 * Kirim pesan WhatsApp berbasis TEMPLATE via Meta Cloud API.
 *
 * @param string $noHp         Nomor WhatsApp tujuan (boleh format 08xxxx atau 628xxxx)
 * @param string $templateName Nama template PERSIS seperti yang terdaftar & approved di WhatsApp Manager
 * @param array  $bodyParams   Isi variabel {{1}}, {{2}}, ... berurutan sesuai body template.
 *                             Tiap elemen wajib string tidak kosong (WhatsApp menolak parameter kosong).
 * @param string $lang         Kode bahasa template, default 'id' (Indonesia) — harus sama persis
 *                             dengan bahasa yang dipilih saat submit template ke Meta.
 * @return array                ['success' => bool, 'response' => mixed]
 */
function kirimWATemplate(string $noHp, string $templateName, array $bodyParams = [], string $lang = 'id'): array
{
    // Normalisasi nomor: 08xxxx -> 628xxxx
    $noHp = preg_replace('/[^0-9]/', '', $noHp);
    if (substr($noHp, 0, 1) === '0') {
        $noHp = '62' . substr($noHp, 1);
    }

    // WhatsApp menolak parameter body yang kosong/whitespace saja -> ganti jadi '-'
    $parameters = array_map(function ($val) {
        $val = trim((string) $val);
        return ['type' => 'text', 'text' => $val === '' ? '-' : $val];
    }, $bodyParams);

    $payload = [
        'messaging_product' => 'whatsapp',
        'to'                => $noHp,
        'type'              => 'template',
        'template'          => [
            'name'     => $templateName,
            'language' => ['code' => $lang],
            'components' => empty($parameters) ? [] : [
                [
                    'type'       => 'body',
                    'parameters' => $parameters,
                ],
            ],
        ],
    ];

    $apiVersion = defined('META_WA_API_VERSION') && META_WA_API_VERSION !== '' ? META_WA_API_VERSION : 'v21.0';
    $url = "https://graph.facebook.com/{$apiVersion}/" . META_WA_PHONE_NUMBER_ID . "/messages";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . META_WA_TOKEN,
        'Content-Type: application/json',
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        error_log('Meta WA cURL error: ' . $curlErr);
        return ['success' => false, 'response' => $curlErr];
    }

    $data = json_decode($response, true);

    if (!is_array($data)) {
        error_log('Meta WA respon tidak valid: ' . $response);
        return ['success' => false, 'response' => $response];
    }

    // Sukses kalau ada messages[0].id dan tidak ada object 'error'
    $sukses = isset($data['messages'][0]['id']) && !isset($data['error']);

    if (!$sukses) {
        error_log('Meta WA gagal kirim ke ' . $noHp . ': ' . json_encode($data));
    }

    return ['success' => $sukses, 'response' => $data];
}

/**
 * Sama seperti kirimWATemplate(), tapi untuk template yang HEADER-nya
 * bertipe Document (lampiran file bisa didownload pelanggan) -- dipakai
 * misalnya untuk template `pesanan_selesai_v4` yang melampirkan invoice
 * PDF. Template tujuan HARUS dibuat di WhatsApp Manager dengan Header
 * type = Document terlebih dulu (lihat docs/whatsapp-templates.md).
 *
 * @param string $noHp          Nomor WhatsApp tujuan.
 * @param string $templateName  Nama template (header-nya harus Document).
 * @param string $dokumenUrl    URL PUBLIK file PDF (harus bisa diakses
 *                              Meta dari internet, bukan localhost).
 * @param string $namaFile      Nama file yang tampil di WhatsApp pelanggan,
 *                              mis. "Invoice-INV-0001.pdf".
 * @param array  $bodyParams    Isi variabel {{1}}, {{2}}, ... di BODY
 *                              (header dokumen tidak punya variabel teks).
 * @param string $lang          Kode bahasa template, default 'id'.
 * @return array                ['success' => bool, 'response' => mixed]
 */
function kirimWATemplateDokumen(string $noHp, string $templateName, string $dokumenUrl, string $namaFile, array $bodyParams = [], string $lang = 'id'): array
{
    $noHp = preg_replace('/[^0-9]/', '', $noHp);
    if (substr($noHp, 0, 1) === '0') {
        $noHp = '62' . substr($noHp, 1);
    }

    $parameters = array_map(function ($val) {
        $val = trim((string) $val);
        return ['type' => 'text', 'text' => $val === '' ? '-' : $val];
    }, $bodyParams);

    $components = [
        [
            'type'       => 'header',
            'parameters' => [
                [
                    'type'     => 'document',
                    'document' => [
                        'link'     => $dokumenUrl,
                        'filename' => $namaFile,
                    ],
                ],
            ],
        ],
    ];
    if (!empty($parameters)) {
        $components[] = [
            'type'       => 'body',
            'parameters' => $parameters,
        ];
    }

    $payload = [
        'messaging_product' => 'whatsapp',
        'to'                => $noHp,
        'type'              => 'template',
        'template'          => [
            'name'       => $templateName,
            'language'   => ['code' => $lang],
            'components' => $components,
        ],
    ];

    $apiVersion = defined('META_WA_API_VERSION') && META_WA_API_VERSION !== '' ? META_WA_API_VERSION : 'v21.0';
    $url = "https://graph.facebook.com/{$apiVersion}/" . META_WA_PHONE_NUMBER_ID . "/messages";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . META_WA_TOKEN,
        'Content-Type: application/json',
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        error_log('Meta WA (dokumen) cURL error: ' . $curlErr);
        return ['success' => false, 'response' => $curlErr];
    }

    $data = json_decode($response, true);
    if (!is_array($data)) {
        error_log('Meta WA (dokumen) respon tidak valid: ' . $response);
        return ['success' => false, 'response' => $response];
    }

    $sukses = isset($data['messages'][0]['id']) && !isset($data['error']);
    if (!$sukses) {
        error_log('Meta WA (dokumen) gagal kirim ke ' . $noHp . ': ' . json_encode($data));
    }

    return ['success' => $sukses, 'response' => $data];
}
