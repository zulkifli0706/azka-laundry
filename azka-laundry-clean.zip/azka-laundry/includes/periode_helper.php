<?php
/**
 * Helper terpusat untuk filter periode laporan/rekap (dashboard_owner.php
 * & laporan_pdf.php) -- termasuk periode KUSTOM (rentang tanggal manual
 * dipilih owner lewat kalender, bukan cuma preset Hari Ini/Minggu/Bulan/Tahun).
 *
 * Validasi tanggal SENGAJA ketat (format Y-m-d via DateTime::createFromFormat,
 * lalu diformat ulang) sebelum ditempel langsung ke string SQL -- supaya
 * aman dari SQL injection walau nilainya berasal dari $_GET.
 */

/**
 * Baca & validasi filter periode dari $_GET, return array siap pakai:
 * ['periode' => string, 'where' => string SQL, 'label' => string, 'dari' => ?string, 'sampai' => ?string]
 */
function resolvePeriodeFilter(array $get): array
{
    $periode = $get['periode'] ?? 'hari_ini';
    $allowed = ['hari_ini', 'minggu_ini', 'bulan_ini', 'tahun_ini', 'tahun_lalu', 'custom'];
    if (!in_array($periode, $allowed, true)) {
        $periode = 'hari_ini';
    }

    $dariOut   = null;
    $sampaiOut = null;

    if ($periode === 'custom') {
        $dariRaw   = (string) ($get['dari'] ?? '');
        $sampaiRaw = (string) ($get['sampai'] ?? '');

        $dariObj   = DateTime::createFromFormat('Y-m-d', $dariRaw);
        $sampaiObj = DateTime::createFromFormat('Y-m-d', $sampaiRaw);

        // Tanggal tidak valid / tidak diisi -> fallback ke Hari Ini supaya
        // halaman tetap tampil normal, bukan error.
        if (!$dariObj || !$sampaiObj) {
            $periode = 'hari_ini';
        } else {
            // Kalau kebalik (dari > sampai), tukar otomatis -- owner tidak
            // perlu mikir urutan klik kalender yang benar.
            if ($dariObj > $sampaiObj) {
                [$dariObj, $sampaiObj] = [$sampaiObj, $dariObj];
            }
            $dariOut   = $dariObj->format('Y-m-d');
            $sampaiOut = $sampaiObj->format('Y-m-d');
        }
    }

    if ($periode === 'custom') {
        $where = "DATE(t.created_at) BETWEEN '{$dariOut}' AND '{$sampaiOut}'";
        $label = 'Kustom (' . date('d/m/Y', strtotime($dariOut)) . ' - ' . date('d/m/Y', strtotime($sampaiOut)) . ')';
    } else {
        $where = match ($periode) {
            'hari_ini'   => "DATE(t.created_at) = CURDATE()",
            'minggu_ini' => "YEARWEEK(t.created_at, 1) = YEARWEEK(CURDATE(), 1)",
            'bulan_ini'  => "YEAR(t.created_at) = YEAR(CURDATE()) AND MONTH(t.created_at) = MONTH(CURDATE())",
            'tahun_ini'  => "YEAR(t.created_at) = YEAR(CURDATE())",
            'tahun_lalu' => "YEAR(t.created_at) = YEAR(CURDATE()) - 1",
        };
        $label = match ($periode) {
            'hari_ini'   => 'Hari Ini',
            'minggu_ini' => 'Minggu Ini',
            'bulan_ini'  => 'Bulan ' . date('F Y'),
            'tahun_ini'  => 'Tahun ' . date('Y'),
            'tahun_lalu' => 'Tahun ' . (date('Y') - 1),
        };
    }

    return [
        'periode' => $periode,
        'where'   => $where,
        'label'   => $label,
        'dari'    => $dariOut,
        'sampai'  => $sampaiOut,
    ];
}

/**
 * Bangun query string tambahan (&dari=...&sampai=...) untuk disisipkan di
 * link-link lain (Cetak PDF, dst) supaya rentang kustom ikut terbawa,
 * bukan cuma nama periode-nya.
 */
function periodeQueryExtra(array $periodeInfo): string
{
    if ($periodeInfo['periode'] !== 'custom') {
        return '';
    }
    return '&dari=' . urlencode($periodeInfo['dari']) . '&sampai=' . urlencode($periodeInfo['sampai']);
}
