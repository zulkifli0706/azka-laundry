<?php
/**
 * Include file ini di halaman (setelah <body>, di bagian bawah sebelum
 * </body> juga boleh) untuk memicu pengiriman notifikasi WA "estimasi
 * diperpanjang" secara bertahap, jeda 30 detik per pesan, TANPA nge-block
 * loading halaman.
 *
 * Wajib set variabel $antrianNotifTerlambat (array of int transaksi_id)
 * dan $csrfTokenJs SEBELUM require file ini.
 */
$daftarIdJson = json_encode($antrianNotifTerlambat ?? []);
?>
<script>
(function () {
    const antrian = <?= $daftarIdJson ?>;
    if (!antrian.length) return;

    const CSRF_TOKEN = <?= json_encode($csrfTokenJs) ?>;
    const JEDA_MIN_MS = 20000; // 20 detik
    const JEDA_MAX_MS = 30000; // 30 detik
    function jedaAcak() {
        return JEDA_MIN_MS + Math.random() * (JEDA_MAX_MS - JEDA_MIN_MS);
    }

    console.log(`Notifikasi keterlambatan: ${antrian.length} nota antre, jeda 20-30 detik (acak) per pesan.`);

    let idx = 0;
    function kirimBerikutnya() {
        if (idx >= antrian.length) {
            console.log('Semua notifikasi keterlambatan selesai dikirim.');
            return;
        }
        const transaksiId = antrian[idx];
        idx++;

        const fd = new FormData();
        fd.append('transaksi_id', transaksiId);
        fd.append('csrf_token', CSRF_TOKEN);

        fetch('kirim_notif_terlambat.php', { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(res => res.json())
            .then(data => {
                console.log(`Notif terlambat transaksi #${transaksiId}:`, data.wa_sent ? 'terkirim' : 'GAGAL', data);
            })
            .catch(err => console.error('Gagal kirim notif terlambat:', err))
            .finally(() => {
                setTimeout(kirimBerikutnya, jedaAcak());
            });
    }

    // Mulai pesan pertama langsung, sisanya menyusul tiap 30 detik.
    kirimBerikutnya();
})();
</script>
