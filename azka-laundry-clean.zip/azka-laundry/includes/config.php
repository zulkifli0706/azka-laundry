<?php
/**
 * Konfigurasi inti aplikasi Azka Laundry.
 * - Koneksi database (PDO)
 * - Session (dengan pengaturan cookie yang lebih aman)
 * - Helper login/role
 * - Helper CSRF token
 * - Helper rate-limit percobaan login
 * - Handler error/exception yang ramah pengguna
 */

// ── MUAT KREDENSIAL DARI .env (kalau ada) ──
// Supaya kredensial (password DB, token WA) tidak hardcode di kode sumber.
// Kalau file .env tidak ditemukan, dipakai nilai default (setara XAMPP lokal)
// supaya aplikasi tetap jalan seperti sebelumnya tanpa setup tambahan.
//
// CATATAN PENTING: sengaja SELALU menimpa nilai dari .env (tidak dicek
// getenv() dulu). Kalau pakai server long-running (mis. `php -S`), putenv()
// dari request sebelumnya "nempel" di proses selama proses itu hidup --
// akibatnya perubahan di .env tidak pernah kebaca lagi tanpa restart total
// server. Karena app ini tidak butuh override dari environment variable
// asli di level OS/hosting, .env selalu jadi sumber kebenaran.
function loadEnvFile(string $path): void {
    if (!is_readable($path)) return;
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        if (!str_contains($line, '=')) continue;
        [$key, $value] = array_map('trim', explode('=', $line, 2));
        // Buang tanda kutip pembungkus jika ada
        $value = trim($value, "\"'");
        if ($key !== '') {
            putenv("$key=$value");
            $_ENV[$key] = $value;
        }
    }
}
loadEnvFile(__DIR__ . '/../.env');

function envOrDefault(string $key, string $default): string {
    $val = getenv($key);
    return ($val === false || $val === '') ? $default : $val;
}

// Konfigurasi Database
define('DB_HOST', envOrDefault('DB_HOST', '127.0.0.1'));
define('DB_NAME', envOrDefault('DB_NAME', 'azka_laundry'));
define('DB_USER', envOrDefault('DB_USER', 'root'));
define('DB_PASS', envOrDefault('DB_PASS', ''));       // XAMPP default: kosong
define('DB_CHAR', envOrDefault('DB_CHAR', 'utf8mb4'));

// Konfigurasi Meta WhatsApp Cloud API (Notifikasi WhatsApp) — SATU-SATUNYA
// jalur notifikasi transaksi baru, siap diambil, selesai, dan keterlambatan.
// META_WA_TOKEN           : Access Token PERMANEN (dari System User), bukan token sementara 24 jam.
//                           Meta Developer > App > WhatsApp > Penyiapan Produksi > "Buat token".
// META_WA_PHONE_NUMBER_ID : "ID Nomor Telepon" nomor WA Business yang sudah terdaftar & verified.
// META_WA_API_VERSION     : versi Graph API, boleh dikosongkan (default v21.0).
define('META_WA_TOKEN', envOrDefault('META_WA_TOKEN', ''));
define('META_WA_PHONE_NUMBER_ID', envOrDefault('META_WA_PHONE_NUMBER_ID', ''));
define('META_WA_API_VERSION', envOrDefault('META_WA_API_VERSION', 'v21.0'));

// APP_URL   : domain publik aplikasi (TANPA trailing slash), dipakai untuk
//             menyusun link invoice.php yang dilampirkan di notifikasi WA
//             "pesanan selesai" (header dokumen template Meta perlu URL
//             publik yang bisa diakses Meta dari internet).
//             OPSIONAL -- kalau dikosongkan/tidak diisi di .env, otomatis
//             dideteksi dari domain yang sedang dipakai mengakses aplikasi
//             (host tempat kasir/owner login ke dashboard), karena itu
//             domain publik yang sama yang dipakai pelanggan juga.
//             Isi manual di .env HANYA kalau auto-deteksi salah (mis. app
//             diakses lewat lebih dari satu domain/subdomain berbeda).
function deteksiAppUrl(): string {
    $manual = trim(envOrDefault('APP_URL', ''));
    if ($manual !== '') {
        return rtrim($manual, '/');
    }
    $host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ($_SERVER['SERVER_PORT'] ?? '') === '443'
        || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
    $skema = $https ? 'https' : 'http';
    // Path dasar aplikasi (mis. "/azka-laundry" kalau tidak di root domain).
    $basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    if ($basePath === '/' || $basePath === '.') $basePath = '';
    return "{$skema}://{$host}{$basePath}";
}
define('APP_URL', deteksiAppUrl());
// INVOICE_LINK_SECRET : kunci rahasia untuk menandatangani link invoice
//             publik (lihat includes/invoice_pdf.php -> tokenInvoice()),
//             supaya orang tidak bisa menebak2 URL invoice nota lain.
//             WAJIB diganti ke string acak sendiri di .env produksi.
define('INVOICE_LINK_SECRET', envOrDefault('INVOICE_LINK_SECRET', 'ganti-secret-ini-di-env'));

// Fonnte & Zenziva SMS SUDAH DIHAPUS TOTAL dari proyek ini (sistem 100%
// pakai Meta WhatsApp Cloud API di atas). Kalau nanti ketemu kode lama yang
// masih require includes/fonnte.php atau includes/sms_helper.php, itu tandanya
// ada sisa referensi yang perlu dibersihkan juga.

// ── ERROR HANDLING RAMAH PENGGUNA ──
// Jangan tampilkan detail error mentah PHP ke pengguna (kebocoran informasi),
// tapi tetap catat ke log server supaya developer bisa debug.
ini_set('display_errors', '0');
error_reporting(E_ALL);

function tampilkanHalamanError(string $judul, string $pesan): void {
    if (!headers_sent()) {
        http_response_code(500);
    }
    echo '<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
    <title>' . htmlspecialchars($judul) . '</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        body{font-family:"Plus Jakarta Sans",Arial,sans-serif;background:#F5F8FB;color:#111827;
             min-height:100vh;display:flex;align-items:center;justify-content:center;margin:0;padding:24px;}
        .box{background:#fff;border:1px solid #DDE5EF;border-radius:16px;padding:32px;max-width:440px;
             text-align:center;box-shadow:0 10px 32px rgba(24,75,133,0.14);}
        .box i{font-size:36px;color:#DC2626;}
        h1{font-size:18px;margin:12px 0 8px;}
        p{font-size:13px;color:#66707F;line-height:1.6;}
        a{display:inline-block;margin-top:16px;color:#184B85;font-weight:700;text-decoration:none;font-size:13px;}
    </style></head><body>
    <div class="box">
        <div><i class="fa fa-triangle-exclamation"></i></div>
        <h1>' . htmlspecialchars($judul) . '</h1>
        <p>' . htmlspecialchars($pesan) . '</p>
        <a href="javascript:history.back()">&larr; Kembali</a>
    </div></body></html>';
}

set_exception_handler(function (Throwable $e) {
    error_log('Uncaught exception: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    tampilkanHalamanError('Terjadi Kesalahan', 'Maaf, terjadi kesalahan pada sistem. Silakan coba lagi atau hubungi admin jika masalah berlanjut.');
});

// Koneksi PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHAR,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Koneksi database gagal: ' . $e->getMessage());
    die('<div style="font-family:sans-serif;padding:20px;background:#fee2e2;color:#991b1b;border-radius:8px;margin:20px">
        <strong>Koneksi database gagal.</strong> Silakan hubungi admin sistem.
    </div>');
}

// Mulai session jika belum aktif (dengan cookie yang lebih aman)
if (session_status() === PHP_SESSION_NONE) {
    $httpsAktif = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'); // untuk hosting di belakang reverse proxy/load balancer
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,       // cookie session tidak bisa diakses lewat JS (mitigasi XSS)
        'samesite' => 'Lax',      // mitigasi sebagian serangan CSRF lintas situs
        'secure'   => $httpsAktif, // cookie cuma dikirim lewat HTTPS kalau situsnya sudah HTTPS
    ]);
    session_start();
}

// ── PENGECEKAN OTOMATIS "ESTIMASI DIPERPANJANG / TERLAMBAT" (TANPA CRON) ──
// File ini (config.php) di-require di SEMUA halaman (dashboard, halaman
// publik cek_status.php, login.php, dst) -- jadi ini titik yang paling
// sering "dilewati" siapa pun yang membuka sistem. Kita numpang di sini
// supaya pengecekan jam 16:00 (H-2 sebelum tutup 18:00) tetap kepicu
// otomatis TANPA perlu setting cron/webcron sama sekali, cukup ada SATU
// orang saja (staf ATAU pelanggan yang cek status) yang membuka halaman
// apa pun setelah jam segitu.
//
// Supaya tidak membebani SETIAP request dengan query database, bagian
// yang "berat" (cek + kirim WA) dijaga cuma boleh jalan MAKSIMAL 1x per
// hari lewat file penanda kecil di folder storage/. Semua request lain
// di hari yang sama cuma baca 1 file kecil (~10 byte) lalu langsung
// selesai -- overhead-nya bisa diabaikan.
//
// Catatan jujur: ini BUKAN penjadwal presisi jam 16:00:00 -- baru kepicu
// begitu ADA kunjungan halaman pertama setelah jam segitu (biasanya cuma
// beda beberapa menit kalau traffic normal). Kalau butuh presisi detik
// per detik, tetap pakai cron_notif_terlambat.php via cron/webcron. Tapi
// untuk kebutuhan sehari-hari, cara ini sudah cukup dan nol-konfigurasi.
function jalankanCekTerlambatOtomatis(PDO $pdo, int $jamTutup = 18, int $jamCekSebelum = 2): void {
    date_default_timezone_set('Asia/Jakarta');
    $jamBatas = $jamTutup - $jamCekSebelum;
    if ((int) date('H') < $jamBatas) return; // belum masuk jam pengecekan hari ini

    $folderStorage = __DIR__ . '/../storage';
    if (!is_dir($folderStorage)) @mkdir($folderStorage, 0775, true);
    $markerFile = $folderStorage . '/cek_terlambat_terakhir.txt';
    $hariIni    = date('Y-m-d');

    if (is_readable($markerFile) && trim((string) file_get_contents($markerFile)) === $hariIni) {
        return; // sudah pernah jalan hari ini, tidak usah diulang
    }

    // Tandai LEBIH DULU sebelum proses berat -- kalau ada 2 request nyaris
    // bersamaan, keduanya boleh saja sama-sama lolos titik ini (race minor,
    // efeknya paling cuma dobel percobaan kirim WA untuk nota yang sama di
    // detik yang sama; cekPerpanjanganEstimasi() sendiri sudah query yang
    // idempotent per hari, jadi dampaknya kecil dan bukan hal kritis).
    @file_put_contents($markerFile, $hariIni);

    require_once __DIR__ . '/estimasi_helper.php';
    require_once __DIR__ . '/meta_whatsapp.php';

    $idTerlambat = cekPerpanjanganEstimasi($pdo, $jamTutup, $jamCekSebelum);
    foreach ($idTerlambat as $i => $transaksiId) {
        kirimNotifKeterlambatan($pdo, $transaksiId);
        // Jeda kecil antar pesan -- jaga-jaga burst rate limit Meta, bukan
        // supaya lambat. Tetap dalam 1 request, jadi kalau nota telat-nya
        // banyak, halaman yang kebetulan "menang" memicu ini akan terasa
        // sedikit lebih lama dimuat -- ini trade-off yang disengaja demi
        // menghindari perlu setup cron.
        if ($i < count($idTerlambat) - 1) {
            usleep((int) ((800 + mt_rand(0, 400)) * 1000));
        }
    }
}
jalankanCekTerlambatOtomatis($pdo);

/**
 * Hapus pesanan online yang statusnya masih 'menunggu' TAPI sudah lewat
 * 24 jam sejak dibuat -- supaya tabel pesanan_online tidak numpuk dengan
 * pesanan yang tidak pernah ditindaklanjuti pelanggan (tidak pernah datang
 * ke laundry). Dijalankan otomatis tiap kali ada request (ringan, cuma 1
 * query DELETE terindeks status+created_at, aman dipanggil sesering apapun
 * untuk skala toko laundry) -- sama seperti pola jalankanCekTerlambatOtomatis()
 * di atas, tidak perlu setup cron terpisah.
 *
 * Pesanan yang statusnya sudah 'dikonversi'/'dibatalkan' TIDAK dihapus di
 * sini -- itu riwayat permanen (transaksi_id-nya masih dipakai untuk audit).
 */
function hapusPesananOnlineKadaluwarsa(PDO $pdo): void {
    $pdo->exec("
        DELETE FROM pesanan_online
        WHERE status = 'menunggu' AND created_at < (NOW() - INTERVAL 24 HOUR)
    ");
}
hapusPesananOnlineKadaluwarsa($pdo);

// Cek apakah user sudah login
function isLoggedIn(): bool {
    return isset($_SESSION['user']) && !empty($_SESSION['user']['id_user']);
}

// Cek role user yang sedang login
function hasRole(string $role): bool {
    return isLoggedIn() && $_SESSION['user']['role'] === $role;
}

// Paksa login — redirect ke login.php jika belum login
function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

// Paksa role tertentu — redirect jika role tidak sesuai
function requireRole(string ...$roles): void {
    requireLogin();
    if (!in_array($_SESSION['user']['role'], $roles, true)) {
        header('Location: login.php');
        exit;
    }
}

// Helper format rupiah
if (!function_exists('formatRupiah')) {
    function formatRupiah($nominal): string {
        return 'Rp ' . number_format((float)$nominal, 0, ',', '.');
    }
}

// Validasi string tanggal 'YYYY-MM-DD' (dipakai untuk filter "Periode Custom"
// di dashboard_owner.php & laporan_pdf.php). Return null kalau formatnya
// salah atau tanggalnya tidak valid (mis. 2026-02-30) -- WAJIB divalidasi
// sebelum ditempel ke query SQL, karena nilainya disisipkan langsung ke
// string SQL (bukan lewat parameter terikat) di kedua file tersebut.
if (!function_exists('tanggalValidOrNull')) {
    function tanggalValidOrNull(?string $val): ?string {
        if ($val === null || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) return null;
        [$y, $m, $d] = array_map('intval', explode('-', $val));
        return checkdate($m, $d, $y) ? $val : null;
    }
}

// ── HELPER PEMBAYARAN (DP / Cicilan) ──
// status_bayar transaksi punya 3 kemungkinan: 'belum_bayar', 'dp', 'sudah_bayar'.
// Kolom transaksi.total_dibayar adalah cache akumulasi seluruh pembayaran
// (SUM dari tabel `pembayaran`) supaya query daftar transaksi tidak perlu
// JOIN + SUM setiap saat. Sumber kebenaran tetap tabel `pembayaran`.

// Sisa tagihan yang masih harus dibayar (tidak pernah minus).
if (!function_exists('sisaBayar')) {
    function sisaBayar($totalHarga, $totalDibayar): float {
        $sisa = (float)$totalHarga - (float)$totalDibayar;
        return $sisa > 0 ? round($sisa, 2) : 0.0;
    }
}

// Tentukan status_bayar baru berdasarkan total sudah dibayar vs total tagihan.
if (!function_exists('hitungStatusBayar')) {
    function hitungStatusBayar($totalHarga, $totalDibayar): string {
        $totalHarga   = (float)$totalHarga;
        $totalDibayar = (float)$totalDibayar;
        if ($totalDibayar <= 0)            return 'belum_bayar';
        if ($totalDibayar >= $totalHarga)  return 'sudah_bayar';
        return 'dp';
    }
}

/**
 * Catat satu pembayaran (DP, pelunasan, atau lunas langsung) untuk sebuah
 * transaksi secara atomik: insert ke `pembayaran`, lalu update cache
 * total_dibayar & status_bayar di `transaksi`. Caller wajib memanggil ini
 * DI DALAM $pdo->beginTransaction() ... commit() miliknya sendiri.
 *
 * @param ?string $namaPengirim Wajib diisi kalau $metode = 'transfer'
 *                               (validasi di sini, bukan cuma di form) --
 *                               dipakai menelusuri transfer kalau ada
 *                               selisih/komplain. Diabaikan (disimpan NULL)
 *                               kalau metode 'tunai'.
 * @param ?string $noPengirim   Sama seperti $namaPengirim, no. rekening/HP
 *                               pengirim transfer.
 * @return array{total_dibayar: float, sisa: float, status_bayar: string}
 */
function catatPembayaran(PDO $pdo, int $transaksiId, float $jumlahBayar, string $metode, int $kasirId, ?string $namaPengirim = null, ?string $noPengirim = null): array {
    $metode = in_array($metode, ['tunai', 'transfer'], true) ? $metode : 'tunai';

    if ($metode === 'transfer') {
        $namaPengirim = trim((string) $namaPengirim);
        $noPengirim   = trim((string) $noPengirim);
        if ($namaPengirim === '') {
            throw new Exception('Nama Pengirim wajib diisi untuk pembayaran Transfer.');
        }
        // No. Rekening/HP pengirim OPSIONAL -- boleh dikosongkan kalau kasir
        // tidak sempat/tidak perlu mencatatnya, nama saja cukup untuk
        // menelusuri lewat notifikasi transfer bank/e-wallet.
    } else {
        $namaPengirim = null;
        $noPengirim   = null;
    }

    $stmt = $pdo->prepare("SELECT total_harga, total_dibayar FROM transaksi WHERE id_transaksi = ? FOR UPDATE");
    $stmt->execute([$transaksiId]);
    $trx = $stmt->fetch();
    if (!$trx) {
        throw new Exception('Transaksi tidak ditemukan.');
    }

    $totalHarga   = (float)$trx['total_harga'];
    $sudahDibayar = (float)$trx['total_dibayar'];
    $sisaSaatIni  = sisaBayar($totalHarga, $sudahDibayar);

    if ($jumlahBayar <= 0) {
        throw new Exception('Jumlah bayar harus lebih dari 0.');
    }
    if ($jumlahBayar > $sisaSaatIni + 0.01) {
        throw new Exception('Jumlah bayar melebihi sisa tagihan (' . formatRupiah($sisaSaatIni) . ').');
    }

    $pdo->prepare("
        INSERT INTO pembayaran (transaksi_id, jumlah_bayar, metode, nama_pengirim, no_pengirim, kasir_id)
        VALUES (?, ?, ?, ?, ?, ?)
    ")->execute([$transaksiId, $jumlahBayar, $metode, $namaPengirim, $noPengirim, $kasirId]);

    $totalDibayarBaru = round($sudahDibayar + $jumlahBayar, 2);
    $statusBaru        = hitungStatusBayar($totalHarga, $totalDibayarBaru);

    $pdo->prepare("
        UPDATE transaksi SET total_dibayar = ?, status_bayar = ?, updated_at = NOW() WHERE id_transaksi = ?
    ")->execute([$totalDibayarBaru, $statusBaru, $transaksiId]);

    return [
        'total_dibayar' => $totalDibayarBaru,
        'sisa'          => sisaBayar($totalHarga, $totalDibayarBaru),
        'status_bayar'  => $statusBaru,
    ];
}

// ── RINCIAN PEMBAYARAN (dipakai di teks notifikasi WA / struk) ──
// Label tampilan untuk metode bayar. Nilai kolom `pembayaran.metode` cuma
// 'tunai'/'transfer' (enum di DB), fungsi ini yang urus kapitalisasinya.
// Kalau metode Transfer DAN ada data pengirim (nama_pengirim/no_pengirim),
// disertakan juga -- mis. "Transfer (a.n. Budi, 081234567890)" -- supaya
// pelanggan & kasir gampang menelusuri kalau ada selisih/komplain transfer.
// Pembayaran LAMA (dicatat sebelum fitur ini ada) tidak punya data
// pengirim -> tetap tampil "Transfer" polos, tidak error.
if (!function_exists('labelMetodeBayar')) {
    function labelMetodeBayar(string $metode, ?string $namaPengirim = null, ?string $noPengirim = null): string {
        if ($metode !== 'transfer') {
            return 'Tunai';
        }
        $namaPengirim = trim((string) $namaPengirim);
        $noPengirim   = trim((string) $noPengirim);
        if ($namaPengirim === '' && $noPengirim === '') {
            return 'Transfer';
        }
        $detail = trim($namaPengirim . ($noPengirim !== '' ? ", {$noPengirim}" : ''), ', ');
        return "Transfer (a.n. {$detail})";
    }
}

/**
 * Rincian pembayaran untuk struk WA, dipecah jadi baris-baris terpisah
 * (bukan satu kalimat digabung) supaya lebih mudah dibaca kayak struk asli:
 * Total biaya / Sudah dibayar / Metode Bayar / Sisa tagihan masing-masing
 * baris sendiri.
 *
 * Membaca SEMUA baris di tabel `pembayaran` milik transaksi ini secara
 * berurutan (bisa lebih dari satu kalau pelanggan bayar bertahap/DP lalu
 * pelunasan). Baris "Metode Bayar":
 *
 * - 1 pembayaran yang langsung melunasi (sisa = 0), ATAU 2+ pembayaran
 *   tapi SEMUA pakai metode yang sama (mis. tunai-tunai) -> cukup nama
 *   metodenya polos, gak perlu label DP/Pelunasan.
 * - 1 pembayaran tapi belum lunas (baru DP, sisa masih > 0) -> dilabeli
 *   "DP (Tunai)" / "DP (Transfer)" biar jelas ini baru DP, belum lunas.
 * - 2+ pembayaran dengan metode BEDA-BEDA (mis. DP tunai, pelunasan
 *   transfer) -> dirinci per pembayaran: pembayaran pertama dilabeli
 *   "DP", sisanya "Pelunasan" (dinomori "Pelunasan 1", "Pelunasan 2", dst
 *   kalau pelunasannya lebih dari sekali/nyicil), masing-masing dengan
 *   jumlah & metodenya sendiri — supaya jelas dari mana asal tiap bagian.
 *
 * PENTING: hasil 'metode' di sini WAJIB tetap 1 baris tanpa newline,
 * karena dipakai sebagai isi salah satu variabel {{n}} template Meta
 * WhatsApp yang sudah disubmit (Meta menolak SELURUH pesan kalau ada
 * parameter body yang mengandung newline/tab).
 *
 * @return array{dibayar: string, metode: string, sisa: string}
 *   Contoh (lunas, satu metode):        ['Rp 15.000', 'Tunai', 'Lunas']
 *   Contoh (DP tunai lalu pelunasan
 *           tunai juga, sudah lunas):   ['Rp 15.000', 'Tunai', 'Lunas']
 *   Contoh (DP tunai lalu pelunasan
 *           transfer, sudah lunas):     ['Rp 15.000', 'DP: Rp 5.000 (Tunai), Pelunasan: Rp 10.000 (Transfer)', 'Lunas']
 *   Contoh (belum bayar, lalu dilunasi
 *           sekaligus transfer):        ['Rp 20.000', 'Transfer', 'Lunas']
 *   Contoh (DP doang, belum ada
 *           pelunasan):                 ['Rp 10.000', 'DP (Tunai)', 'Rp 5.000']
 *   Contoh (belum bayar sama sekali):   ['Rp 0', '-', 'Rp 15.000']
 */
function rincianPembayaranStruk(PDO $pdo, int $transaksiId, float $totalHarga, float $totalDibayar): array {
    $stmt = $pdo->prepare("SELECT jumlah_bayar, metode, nama_pengirim, no_pengirim FROM pembayaran WHERE transaksi_id = ? ORDER BY created_at ASC, id_pembayaran ASC");
    $stmt->execute([$transaksiId]);
    $daftarBayar = $stmt->fetchAll();

    $sisa    = sisaBayar($totalHarga, $totalDibayar);
    $sisaTxt = $sisa > 0 ? formatRupiah($sisa) : 'Lunas';

    return [
        'dibayar' => formatRupiah($totalDibayar),
        'metode'  => teksMetodeBayarGabungan($daftarBayar, $sisa),
        'sisa'    => $sisaTxt,
    ];
}

/**
 * Versi RINGKAS metode bayar khusus untuk kolom "Metode" di laporan rekap
 * (laporan_pdf.php) -- SENGAJA beda dari teksMetodeBayarGabungan() yang
 * dipakai di struk WA. Laporan rekap isinya bisa ratusan baris, jadi kalau
 * tiap baris dipaksa nampilin rincian penuh "DP: Rp x (Tunai), Pelunasan:
 * Rp y (Transfer)" + nama pengirim, tabelnya jadi melebar 2-3 baris per
 * transaksi dan susah dipindai cepat. Rincian selengkap itu (siapa
 * pengirimnya, kapan, berapa tiap tahap) sudah ada di modal detail
 * dashboard owner -- laporan rekap cukup tahu garis besarnya: Tunai,
 * Transfer, atau Campuran (kalau bayarnya lewat 2 metode berbeda,
 * mis. DP tunai lalu pelunasan transfer).
 *
 * @param array $daftarBayar Baris-baris pembayaran 1 transaksi (kolom
 *                            minimal: metode), urutan tidak penting di sini.
 */
function metodeRingkasUntukLaporan(array $daftarBayar): string {
    if (empty($daftarBayar)) {
        return '-';
    }
    $metodeUnik = array_unique(array_column($daftarBayar, 'metode'));
    if (count($metodeUnik) === 1) {
        return $metodeUnik[array_key_first($metodeUnik)] === 'transfer' ? 'Transfer' : 'Tunai';
    }
    return 'Campuran';
}

/**
 * Inti logika penyusunan teks "Metode Bayar" (dipakai rincianPembayaranStruk()
 * di atas untuk struk WA, DAN laporan_pdf.php untuk kolom "Metode" per baris
 * di laporan rekap owner) -- dipisah jadi fungsi sendiri supaya laporan_pdf.php
 * tidak perlu query ulang tabel `pembayaran` satu-satu per baris transaksi
 * (bisa sampai 1000 baris), cukup 1 query gabungan lalu di-groupBy transaksi_id
 * di PHP, baru dipanggil fungsi ini per grup.
 *
 * @param array $daftarBayar Baris-baris pembayaran 1 transaksi (kolom minimal:
 *                            jumlah_bayar, metode, nama_pengirim, no_pengirim),
 *                            URUT dari yang paling awal (created_at ASC).
 * @param float $sisa         Sisa tagihan transaksi ini (hasil sisaBayar()).
 * @see rincianPembayaranStruk() untuk penjelasan lengkap aturan & contoh hasil.
 */
function teksMetodeBayarGabungan(array $daftarBayar, float $sisa): string {
    if (empty($daftarBayar)) {
        return '-';
    }

    if (count($daftarBayar) === 1) {
        $labelMetode = labelMetodeBayar($daftarBayar[0]['metode'], $daftarBayar[0]['nama_pengirim'], $daftarBayar[0]['no_pengirim']);
        return $sisa > 0 ? ('DP (' . $labelMetode . ')') : $labelMetode;
    }

    $labelUnik = array_unique(array_map(
        fn($b) => labelMetodeBayar($b['metode'], $b['nama_pengirim'], $b['no_pengirim']),
        $daftarBayar
    ));

    if (count($labelUnik) === 1) {
        return $labelUnik[array_key_first($labelUnik)];
    }

    $jumlahPelunasan = count($daftarBayar) - 1;
    $bagian = [];
    foreach ($daftarBayar as $i => $b) {
        $jumlahFmt = formatRupiah((float)$b['jumlah_bayar']);
        $metodeFmt = labelMetodeBayar($b['metode'], $b['nama_pengirim'], $b['no_pengirim']);
        $label = $i === 0 ? 'DP' : ($jumlahPelunasan > 1 ? ('Pelunasan ' . $i) : 'Pelunasan');
        $bagian[] = "{$label}: {$jumlahFmt} ({$metodeFmt})";
    }
    return implode(', ', $bagian);
}

// ── CSRF TOKEN ──
// Setiap form/aksi POST wajib menyertakan token ini supaya tidak bisa
// dipicu dari situs lain (Cross-Site Request Forgery).
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Cetak input hidden CSRF, dipakai di dalam <form>...</form>
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

// Verifikasi token CSRF dari $_POST (atau nilai custom untuk request AJAX/JSON)
function verify_csrf(?string $token = null): bool {
    $token = $token ?? ($_POST['csrf_token'] ?? '');
    return $token !== '' && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// ── RATE LIMIT LOGIN ──
// Membatasi percobaan login yang gagal beruntun supaya tidak mudah
// ditebak-tebak (brute force) melalui form login.
const LOGIN_MAX_ATTEMPTS = 5;
const LOGIN_LOCK_SECONDS = 60;

function loginIsLocked(): bool {
    return !empty($_SESSION['login_locked_until']) && time() < $_SESSION['login_locked_until'];
}

function loginSecondsRemaining(): int {
    if (!loginIsLocked()) return 0;
    return max(0, $_SESSION['login_locked_until'] - time());
}

function registerFailedLogin(): void {
    $_SESSION['login_fail_count'] = ($_SESSION['login_fail_count'] ?? 0) + 1;
    if ($_SESSION['login_fail_count'] >= LOGIN_MAX_ATTEMPTS) {
        $_SESSION['login_locked_until'] = time() + LOGIN_LOCK_SECONDS;
        $_SESSION['login_fail_count']   = 0;
    }
}

function resetLoginAttempts(): void {
    unset($_SESSION['login_fail_count'], $_SESSION['login_locked_until']);
}
