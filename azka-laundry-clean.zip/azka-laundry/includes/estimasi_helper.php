<?php
/**
 * Auto-perpanjang tanggal_estimasi kalau nota masih belum siap_diambil.
 *
 * Ada 2 kondisi yang memicu perpanjangan +1 hari:
 * 1. Nota SUDAH TELAT dari hari-hari sebelumnya (tanggal_estimasi < hari
 *    ini) -- ini menutup "celah": kalau sebelumnya tidak ada staf yang
 *    buka halaman pas jam pengecekan sore, nota jadi telat tanpa pernah
 *    diperpanjang. Kondisi ini TIDAK menunggu jam tutup lagi -- begitu ada
 *    yang buka salah satu halaman terkait, jam berapa pun, nota yang sudah
 *    telat langsung dikejar/digeser ke besok.
 * 2. Nota jatuh tempo HARI INI dan sudah masuk jam pengecekan (H-2 jam
 *    sebelum toko tutup) -- diperpanjang seperti biasa.
 *
 * Selama nota belum siap_diambil, pengecekan ini akan terus menggeser
 * tanggal_estimasi +1 hari setiap kali dipanggil di hari berikutnya, jadi
 * nota yang berkali-kali telat akan terus mendapat perpanjangan otomatis
 * (bukan cuma sekali).
 *
 * Cara pakai: panggil cekPerpanjanganEstimasi($pdo) di halaman yang sering
 * dibuka staff pencucian (dashboard_pencucian.php, antrian.php,
 * sedang_diproses.php) — SETELAH require config.php & requireRole().
 *
 * Aman dipanggil berkali-kali dalam satu hari (idempotent): begitu sebuah
 * nota diperpanjang, tanggal_estimasi-nya langsung maju ke besok, jadi
 * kondisi "tanggal_estimasi <= hari ini" sudah tidak match lagi kalau
 * fungsi ini dipanggil ulang di hari yang sama -> tidak dobel-tambah.
 *
 * CATATAN (fix histori keterlambatan): setiap nota yang kena perpanjangan
 * di sini juga ditandai pernah_terlambat = 1 di tabel transaksi. Ini FAKTA
 * PERMANEN per nota -- tidak ikut ke-reset walau tanggal_estimasi-nya
 * kemudian dimajukan terus. Semua halaman yang menampilkan badge TERLAMBAT
 * harus baca kolom ini (bukan cuma bandingkan tanggal_estimasi vs hari ini),
 * supaya nota yang pernah telat tetap kelihatan telat di riwayatnya.
 *
 * CATATAN (notifikasi WA cuma 1x/hari): fungsi ini dipanggil dari BEBERAPA
 * tempat independen -- auto-check global di includes/config.php (jalan di
 * SETIAP halaman), plus panggilan langsung di antrian.php,
 * dashboard_pencucian.php, dan sedang_diproses.php. Kalau dua staf membuka
 * dua halaman itu nyaris bersamaan, tanpa penguncian yang tepat KEDUANYA
 * bisa sama-sama membaca nota yang sama sebagai "masih terlambat" sebelum
 * salah satunya sempat menyimpan perubahan -- akibatnya WA "terlambat"
 * terkirim dobel untuk nota yang sama di hari yang sama.
 *
 * Supaya benar-benar aman dari race ini (bukan cuma mengandalkan urutan
 * eksekusi PHP yang kebetulan berurutan), pengambilan nota yang berhak
 * dinotifikasi dibungkus dalam SATU TRANSAKSI dengan `SELECT ... FOR UPDATE`:
 * baris yang sedang diperiksa oleh satu request dikunci sampai request itu
 * commit, jadi request lain yang mencoba memeriksa baris yang sama di waktu
 * bersamaan akan MENUNGGU, lalu setelah lock lepas ia akan melihat kolom
 * `notif_terlambat_terakhir` sudah = hari ini dan otomatis tidak
 * mengambilnya lagi. Kolom inilah (bukan lagi tanggal_estimasi) yang jadi
 * penanda resmi "sudah dinotifikasi hari ini", supaya statusnya jelas dan
 * tidak bergantung pada efek samping pergeseran tanggal_estimasi.
 *
 * @param PDO $pdo
 * @param int $jamTutup       Jam tutup toko (format 24 jam), default 18 (jam 18:00)
 * @param int $jamCekSebelum  Berapa jam sebelum tutup pengecekan mulai berlaku, default 2
 * @return int[] Daftar transaksi_id yang tanggal_estimasi-nya baru saja
 *               diperpanjang dan PERLU dikirimi notifikasi WA. Tanggal di
 *               database sudah langsung ter-update saat fungsi ini return;
 *               pengiriman WA-nya sendiri diserahkan ke caller (dijalankan
 *               bertahap dengan jeda dari sisi browser, supaya halaman
 *               tidak nge-freeze kalau nota telat-nya banyak).
 */
function cekPerpanjanganEstimasi(PDO $pdo, int $jamTutup = 18, int $jamCekSebelum = 2): array {
    date_default_timezone_set('Asia/Jakarta');

    $jamSekarang = (int) date('H');
    $jamBatas    = $jamTutup - $jamCekSebelum; // contoh: tutup 18:00, cek mulai jam 16:00

    // Sudah masuk jam pengecekan sore ini -> ikut tangkap nota yang JATUH
    // TEMPO HARI INI juga. Kalau belum, cuma tangkap yang sudah BENAR-BENAR
    // TELAT dari hari sebelumnya (nota ini nggak perlu nunggu jam tutup lagi,
    // karena sudah kepalang telat).
    $kondisi = $jamSekarang >= $jamBatas
        ? 't.tanggal_estimasi <= CURDATE()'
        : 't.tanggal_estimasi < CURDATE()';

    // Transaksi + SELECT ... FOR UPDATE: mengunci baris kandidat sampai kita
    // commit, supaya panggilan lain yang bersamaan tidak bisa ikut mengambil
    // nota yang sama sebelum kita selesai menandainya sudah dinotifikasi
    // hari ini. Ini yang membuat "1x notifikasi per hari" benar-benar
    // terjamin, bukan cuma kebetulan berurutan.
    // (Jaga-jaga kalau pemanggil kebetulan sudah punya transaksi aktif --
    // jangan buka transaksi baru di atasnya, cukup numpang di transaksi yang
    // sudah ada supaya tidak error "there is already an active transaction".)
    $transaksiMilikSendiri = !$pdo->inTransaction();
    if ($transaksiMilikSendiri) {
        $pdo->beginTransaction();
    }
    try {
        $stmt = $pdo->prepare("
            SELECT t.id_transaksi, t.id_nota, t.nama_pelanggan, t.no_hp_pelanggan, t.tanggal_estimasi
            FROM transaksi t
            JOIN status_cucian s ON s.transaksi_id = t.id_transaksi
            WHERE $kondisi
            AND s.status IN ('dalam_antrian', 'sedang_diproses')
            AND (t.notif_terlambat_terakhir IS NULL OR t.notif_terlambat_terakhir < CURDATE())
            FOR UPDATE
        ");
        $stmt->execute();
        $daftarTelat = $stmt->fetchAll();

        if (empty($daftarTelat)) {
            if ($transaksiMilikSendiri) $pdo->commit();
            return [];
        }

        // Selalu digeser ke BESOK (bukan cuma +1 hari dari tanggal_estimasi
        // lama) -- supaya nota yang sudah telat berhari-hari langsung
        // ke-catch-up dalam satu kali jalan, bukan nambah pelan-pelan +1 hari
        // per kunjungan halaman. notif_terlambat_terakhir ditandai HARI INI
        // di transaksi yang sama supaya klaim baris & penandaan "sudah
        // dinotifikasi" atomik, tidak terpisah jadi dua langkah yang bisa
        // diselang oleh request lain.
        $stmtUpdate = $pdo->prepare("
            UPDATE transaksi
            SET tanggal_estimasi = DATE_ADD(CURDATE(), INTERVAL 1 DAY),
                pernah_terlambat = 1,
                notif_terlambat_terakhir = CURDATE()
            WHERE id_transaksi = ?
        ");

        $idTerlambat = [];
        foreach ($daftarTelat as $trx) {
            $stmtUpdate->execute([$trx['id_transaksi']]);
            $idTerlambat[] = (int) $trx['id_transaksi'];
        }

        if ($transaksiMilikSendiri) $pdo->commit();
        return $idTerlambat;
    } catch (\Throwable $e) {
        if ($transaksiMilikSendiri) $pdo->rollBack();
        error_log('cekPerpanjanganEstimasi gagal, transaksi dibatalkan: ' . $e->getMessage());
        return [];
    }
}

/**
 * Kirim SATU notifikasi WA "estimasi diperpanjang" untuk satu transaksi.
 * Dipanggil satu-per-satu (dengan jeda di sisi browser) oleh
 * kirim_notif_wa.php, BUKAN dipanggil langsung dalam loop server
 * supaya tidak nge-block/timeout halaman saat nota telat banyak.
 *
 * Memakai template Meta WhatsApp `estimasi_diperpanjang`.
 *
 * @return bool true kalau WA berhasil terkirim
 */
function kirimNotifKeterlambatan(PDO $pdo, int $transaksiId): bool {
    $stmt = $pdo->prepare("SELECT nama_pelanggan, no_hp_pelanggan, id_nota, tanggal_estimasi FROM transaksi WHERE id_transaksi = ?");
    $stmt->execute([$transaksiId]);
    $trx = $stmt->fetch();
    if (!$trx) return false;

    require_once __DIR__ . '/meta_whatsapp.php';

    $tglFmt = date('d/m/Y', strtotime($trx['tanggal_estimasi']));

    $waResult = kirimWATemplate($trx['no_hp_pelanggan'], 'estimasi_diperpanjang', [
        $trx['nama_pelanggan'], $trx['id_nota'], $tglFmt,
    ]);
    if (!$waResult['success']) {
        error_log('Gagal kirim WA notif keterlambatan untuk nota ' . $trx['id_nota'] . ': ' . json_encode($waResult['response']));
    }
    return $waResult['success'];
}