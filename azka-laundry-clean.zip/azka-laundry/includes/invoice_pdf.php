<?php
/**
 * Generator PDF invoice/struk untuk pelanggan — dipakai oleh invoice.php
 * (endpoint publik yang linknya dilampirkan di notifikasi WA "pesanan
 * selesai") dan bisa juga dipanggil manual kalau perlu.
 *
 * Pakai library FPDF (vendor/fpdf/fpdf.php) yang di-vendor manual TANPA
 * Composer — supaya tidak perlu jalankan `composer install` di server
 * produksi. FPDF dipilih (bukan dompdf) karena invoice ini murni teks +
 * tabel sederhana, tidak butuh rendering HTML/CSS.
 */

require_once __DIR__ . '/../vendor/fpdf/fpdf.php';

/**
 * Token akses invoice publik — supaya invoice.php bisa diakses TANPA
 * login (pelanggan buka dari WA, bukan dari dashboard), tapi tidak bisa
 * ditebak-tebak nomor notanya (mis. INV-0001, INV-0002, dst berurutan).
 * Token = HMAC-SHA256(id_nota, INVOICE_LINK_SECRET), dipotong 16 karakter
 * — cukup panjang untuk sulit ditebak, tidak kedaluwarsa (invoice adalah
 * bukti transaksi permanen, wajar kalau pelanggan buka linknya kapan saja).
 */
function tokenInvoice(string $idNota): string {
    return substr(hash_hmac('sha256', $idNota, INVOICE_LINK_SECRET), 0, 16);
}

function tokenInvoiceValid(string $idNota, string $token): bool {
    return hash_equals(tokenInvoice($idNota), $token);
}

/**
 * Bangun objek FPDF berisi invoice untuk 1 transaksi, siap di-Output().
 *
 * @throws RuntimeException kalau transaksi tidak ditemukan.
 */
function buatInvoicePdf(PDO $pdo, int $transaksiId): FPDF {
    $stmt = $pdo->prepare("
        SELECT t.nama_pelanggan, t.no_hp_pelanggan, t.id_nota, t.total_harga,
               t.total_dibayar, t.status_bayar, t.created_at,
               sc.status AS status_cucian, sc.updated_at AS tanggal_diambil
        FROM transaksi t
        LEFT JOIN status_cucian sc ON sc.transaksi_id = t.id_transaksi
        WHERE t.id_transaksi = ?
    ");
    $stmt->execute([$transaksiId]);
    $trx = $stmt->fetch();
    if (!$trx) {
        throw new RuntimeException('Transaksi tidak ditemukan');
    }

    $stmtItem = $pdo->prepare("
        SELECT dt.qty, dt.subtotal, dt.harga_satuan,
               COALESCE(ib.nama_item, dt.keterangan, 'Item') AS nama_item,
               COALESCE(ib.satuan, '') AS satuan
        FROM detail_transaksi dt
        LEFT JOIN detail_barang ib ON ib.id_barang = dt.detail_barang_id
        WHERE dt.transaksi_id = ?
    ");
    $stmtItem->execute([$transaksiId]);
    $items = $stmtItem->fetchAll();

    $stmtBayar = $pdo->prepare("
        SELECT jumlah_bayar, metode, nama_pengirim, no_pengirim, created_at
        FROM pembayaran WHERE transaksi_id = ? ORDER BY created_at ASC, id_pembayaran ASC
    ");
    $stmtBayar->execute([$transaksiId]);
    $pembayaran = $stmtBayar->fetchAll();

    $rp = fn($n) => 'Rp ' . number_format((float) $n, 0, ',', '.');
    $sisa = max(0.0, (float) $trx['total_harga'] - (float) $trx['total_dibayar']);

    $pdf = new FPDF('P', 'mm', 'A5');
    $pdf->SetMargins(12, 12, 12);
    $pdf->AddPage();
    $pdf->SetAutoPageBreak(true, 12);

    // ── Kop ──
    $pdf->SetFont('Helvetica', 'B', 15);
    $pdf->Cell(0, 7, 'Azka Laundry', 0, 1, 'C');
    $pdf->SetFont('Helvetica', '', 9);
    $pdf->Cell(0, 5, 'Invoice / Struk Transaksi', 0, 1, 'C');
    $pdf->Ln(2);
    $pdf->SetDrawColor(180, 180, 180);
    $pdf->Line(12, $pdf->GetY(), 148 - 12, $pdf->GetY());
    $pdf->Ln(4);

    // ── Info transaksi ──
    $pdf->SetFont('Helvetica', '', 10);
    $labelW = 32;
    $tglDiambilFmt = ($trx['status_cucian'] === 'selesai' && !empty($trx['tanggal_diambil']))
        ? date('d/m/Y H:i', strtotime($trx['tanggal_diambil']))
        : '-';
    $baris = [
        ['No. Nota', $trx['id_nota']],
        ['Tanggal Masuk', date('d/m/Y H:i', strtotime($trx['created_at']))],
        ['Tanggal Diambil', $tglDiambilFmt],
        ['Pelanggan', $trx['nama_pelanggan']],
        ['No. HP', $trx['no_hp_pelanggan']],
    ];
    foreach ($baris as [$label, $val]) {
        $pdf->Cell($labelW, 6, $label, 0, 0);
        $pdf->Cell(4, 6, ':', 0, 0);
        $pdf->Cell(0, 6, (string) $val, 0, 1);
    }
    $pdf->Ln(3);

    // ── Tabel rincian barang ──
    $pdf->SetFont('Helvetica', 'B', 10);
    $pdf->SetFillColor(235, 235, 235);
    $wNo = 8; $wNama = 70; $wQty = 22; $wSub = 24;
    $pdf->Cell($wNo, 7, 'No', 1, 0, 'C', true);
    $pdf->Cell($wNama, 7, 'Barang', 1, 0, 'L', true);
    $pdf->Cell($wQty, 7, 'Qty', 1, 0, 'C', true);
    $pdf->Cell($wSub, 7, 'Subtotal', 1, 1, 'R', true);

    $pdf->SetFont('Helvetica', '', 10);
    $no = 1;
    foreach ($items as $it) {
        $qtyFmt = rtrim(rtrim((string) $it['qty'], '0'), '.');
        $satuan = $it['satuan'] !== '' ? ' ' . $it['satuan'] : '';
        $pdf->Cell($wNo, 7, (string) $no, 1, 0, 'C');
        $pdf->Cell($wNama, 7, (string) $it['nama_item'], 1, 0, 'L');
        $pdf->Cell($wQty, 7, $qtyFmt . $satuan, 1, 0, 'C');
        $pdf->Cell($wSub, 7, $rp($it['subtotal']), 1, 1, 'R');
        $no++;
    }
    if (empty($items)) {
        $pdf->Cell($wNo + $wNama + $wQty + $wSub, 7, '-', 1, 1, 'C');
    }

    $pdf->SetFont('Helvetica', 'B', 10);
    $pdf->Cell($wNo + $wNama + $wQty, 7, 'Total Biaya', 1, 0, 'R');
    $pdf->Cell($wSub, 7, $rp($trx['total_harga']), 1, 1, 'R');
    $pdf->Ln(3);

    // ── Rincian pembayaran ──
    $pdf->SetFont('Helvetica', 'B', 10);
    $pdf->Cell(0, 6, 'Rincian Pembayaran', 0, 1);
    $pdf->SetFont('Helvetica', '', 10);
    if (empty($pembayaran)) {
        $pdf->Cell(0, 6, 'Belum ada pembayaran tercatat', 0, 1);
    } else {
        foreach ($pembayaran as $i => $b) {
            $label = $i === 0 ? 'DP/Pembayaran 1' : ('Pembayaran ' . ($i + 1));
            $metodeTxt = ucfirst((string) $b['metode']);
            if ($b['metode'] === 'transfer' && !empty($b['nama_pengirim'])) {
                $metodeTxt = 'Transfer a.n. ' . $b['nama_pengirim'] . (!empty($b['no_pengirim']) ? ' (' . $b['no_pengirim'] . ')' : '');
            }
            $pdf->Cell($labelW, 6, $label, 0, 0);
            $pdf->Cell(4, 6, ':', 0, 0);
            // MultiCell (bukan Cell) supaya nama pengirim yang panjang bisa
            // membungkus ke baris berikutnya, bukan terpotong di tepi kertas.
            $pdf->MultiCell(0, 6, $rp($b['jumlah_bayar']) . ' (' . $metodeTxt . ', ' . date('d/m/Y', strtotime($b['created_at'])) . ')', 0, 'L');
        }
    }
    $pdf->Ln(1);
    $pdf->Cell($labelW, 6, 'Total Dibayar', 0, 0);
    $pdf->Cell(4, 6, ':', 0, 0);
    $pdf->Cell(0, 6, $rp($trx['total_dibayar']), 0, 1);
    $pdf->Cell($labelW, 6, 'Sisa Tagihan', 0, 0);
    $pdf->Cell(4, 6, ':', 0, 0);
    $pdf->SetFont('Helvetica', 'B', 10);
    $pdf->Cell(0, 6, $sisa > 0 ? $rp($sisa) : 'LUNAS', 0, 1);

    $pdf->Ln(6);
    $pdf->SetFont('Helvetica', 'I', 8);
    $pdf->SetTextColor(120, 120, 120);
    $pdf->MultiCell(0, 4.5, 'Invoice ini dibuat otomatis oleh sistem Azka Laundry dan sah tanpa tanda tangan basah. Simpan sebagai bukti transaksi Anda. Terima kasih telah mempercayakan cucian Anda kepada kami.', 0, 'C');

    return $pdf;
}
